package com.moub.PERDAY.ui.userStatus

interface UserStatusView {
    fun employerNavigate()
    fun employeeNavigate()
    fun showProgress()
    fun hideProgress()
    fun toast(message:String)

}