package com.moub.PERDAY.ui.base


import androidx.fragment.app.Fragment

class BaseCalendar : Fragment()  {




}
