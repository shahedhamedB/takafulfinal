package com.moub.PERDAY.ui.employee.auth.loign

interface LoginContract {
    fun showProgress()
    fun hideProgress()
    fun setEmailError()
    fun setPasswordError()
    fun navigateToHome()
    fun navigateRestPassword()
    fun toast(message:String)

}