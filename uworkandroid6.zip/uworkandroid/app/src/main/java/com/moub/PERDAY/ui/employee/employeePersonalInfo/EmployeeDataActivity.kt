package com.moub.PERDAY.ui.employee.employeePersonalInfo

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Spinner
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.ui.base.BaseActivity
import com.moub.PERDAY.ui.employee.employeeWorkInfo.EmployeeWorkinfoActivity
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_employee_data.*


class EmployeeDataActivity : BaseActivity(), EmployeeDataContract, EmployeeDataPresenter.listner {
    private var language: String =""
    private var material: String = ""

    val presenter = EmployeeDataPresenter(this)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_employee_data)
        getCurrentLocationBtn.setOnClickListener {
            progressBar2.visibility = View.VISIBLE
            getCurrentLocation()
        }

        linearLayout2.setOnClickListener {
            progressBar2.visibility = View.VISIBLE
            getCurrentLocation()
        }
        spinners()
        skipBtn.setOnClickListener { EmployeeWorkinfoActivity.start(this)
        finish()}
        nextBtn.setOnClickListener { checkError() }
    }


    fun onSuccess(
        languagesEmployee: String, material: String, helth: String,
        familySize: String,
        familyWork: String,
        year: String,
        month: String,
        day: String,
        location: String
    ) {
        fireStoreManager.saveEmployeePersonalInfo(
            this, languagesEmployee,
            material,
            helth,
            familySize,
            familyWork,
            year,
            month,
            day,
            location
        )

    }

    @SuppressLint("SetTextI18n")
    fun getCurrentLocation() {

        getLocation { longValue, latValue ->
            presenter.getCountryName(this, this, latValue, longValue) { location, subLocality, countryName, lon, lat ->
                val country = location
                val SubLocality = subLocality
                val CountryName = countryName
                txtLong.text = "$CountryName , $country , $SubLocality"
                CacheManager.instance.setLongEmployee(lon)
                CacheManager.instance.setLatEmployee(lat)
                CacheManager.instance.setCountryEmployee(CountryName)


            }
        }
    }


    override fun setLanguageSpinner(onClick: (String) -> Unit) {
        presenter.spinner(
            LanguageSpinner, resources.getStringArray(R.array.language)
        ) { postion ->
            onClick(postion)
        }
    }

    override fun setMaterialStatusSpinner() {
        presenter.spinner(
            maretalStatus, resources.getStringArray(R.array.material)
        ) { postion ->
            this.material = postion

        }
    }

    override fun setHelthConditionsSpinner() {
        presenter.spinner(
            helthConditionsSpinner, resources.getStringArray(R.array.helth)
        ) { postion ->
            CacheManager.instance.setHelth(postion)
        }
    }
    override fun setfamilySizeSpinner() {
        presenter.spinner(
            familySizeSpinner, resources.getStringArray(R.array.familySize)
        ) { postion ->
            CacheManager.instance.setFamilySize(postion)
        }
    }
    override fun setfamilyJobSpinner() {
        presenter.spinner(
            familyJob, resources.getStringArray(R.array.familyWork)
        ) { postion ->
            CacheManager.instance.setFamilyWork(postion)
        }
    }

    override fun setYearSpinner() {
        presenter.spinner(
            yearSpinner, resources.getStringArray(R.array.year)
        ) { postion ->
            CacheManager.instance.setBirthdayYear(postion)
        }
    }

    override fun setMonthSpinner() {
        presenter.spinner(
            monthSpinner, resources.getStringArray(R.array.month)
        ) { postion ->
            CacheManager.instance.setBirthdayMonth(postion)
        }
    }

    override fun setDaySpinner() {
        presenter.spinner(
            daysSpinner, resources.getStringArray(R.array.day)

        ) { postion ->
            CacheManager.instance.setBirthdayDay(postion)
        }
    }

    fun spinners(){
        setLanguageSpinner{onclick-> language = onclick}
        setMaterialStatusSpinner()
        setHelthConditionsSpinner()
        setfamilySizeSpinner()
        setfamilyJobSpinner()
        setYearSpinner()
        setMonthSpinner()
        setDaySpinner()
    }


    override fun spinner(languages: Array<String>, spinner: Spinner, postion: (String) -> Unit) {
        baseSpinner(languages, spinner){onClick->
            postion(onClick)
        }
    }

    override fun hideProgressPar() {
        progressBar2.visibility = View.GONE
    }

    fun checkError() {
        val languagesEmployee = this.language
        val location = CacheManager.instance.getLongEmployee() + CacheManager.instance.getLatEmployee()
        val material = this.material
        val helth = CacheManager.instance.getHelth()
        val familySize = CacheManager.instance.getfamilySize()
        val familyWork = CacheManager.instance.getfamilyWork()
        val year = CacheManager.instance.getBirthdayYear()
        val month = CacheManager.instance.getBirthdayMonth()
        val day = CacheManager.instance.getBirthdayDay()

//        val Bithday = year.toInt() - Calendar.getInstance().get(Calendar.YEAR)
        when {
            languagesEmployee == "Please Choose Language" -> AppLogger.toast(this, "please choose language")
            material == "Please select your material" -> AppLogger.toast(this, "Please select your material")
            helth == "please select helth status" -> AppLogger.toast(this, "please select helth status")
            familySize == "familySize" -> AppLogger.toast(this, "please select familySize")
            familyWork == "familyWork" -> AppLogger.toast(this, "please select familyWork")
            year == "year" -> AppLogger.toast(this, "please select year birthday")
            month == "month" -> AppLogger.toast(this, "please select month birthday")
            day == "day" -> AppLogger.toast(this, "please select day birthday")
//            Bithday < 18 -> AppLogger.toast(this, "Age must be above 18")
            location == null -> AppLogger.toast(this, "please select your current location")

            else -> onSuccess(languagesEmployee, material, helth, familySize, familyWork, year, month, day, location)

        }

    }


    companion object {
        fun start(context: Context) {
            val intent = Intent(context, EmployeeDataActivity::class.java)
            context.startActivity(intent)
        }
    }
    private var exit: Boolean? = false
    override fun onBackPressed() {
        if (exit!!) {
            finish() // finish activity
        } else {
            AppLogger.toast(
                this, "Press Back again to Exit."
            )
            exit = true
            Handler().postDelayed({ exit = false }, 3 * 1000)
        }
    }
}

