package com.moub.PERDAY.ui.employer.auth.login

import android.content.Context

class LoginPresenter(var loginContract: LoginContract, val loginInteractor: LoginInteractor) :
    LoginInteractor.OnLoginFinishedListener {
    fun validateCredentials(email: String, password: String,context: Context) {
        loginContract.showProgress()
        loginInteractor.logIn(email, password, this,context)
    }

    override fun onEmailError() {
        loginContract.apply {
            setEmailError()
            hideProgress()
        }
    }

    override fun onPasswordError() {
        loginContract.apply {
            setPasswordError()
            hideProgress()
        }
    }

    override fun onSuccess(email: String, password: String,context: Context) {
        loginInteractor.employerLogin(email, password,context,this)
    }

    override fun onNavigate() {
        loginContract.navigateToHome()
    }

    override fun toast(toast: String) {
        loginContract.toast(toast)
    }

    override fun hideProgress() {
        loginContract.hideProgress()
    }
}