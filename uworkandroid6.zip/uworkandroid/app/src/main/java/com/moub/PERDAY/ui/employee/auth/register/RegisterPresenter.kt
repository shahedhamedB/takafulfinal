package com.moub.PERDAY.ui.employee.auth.register

class RegisterPresenter(val registerContract: RegisterContract, val registerInteractor: RegisterInteractor) :
    RegisterInteractor.OnSignUpFinishedListener {

    fun validateCredentials(email: String, password: String, name: String) {
        registerContract.showProgress()
        registerInteractor.signUp(email, password, name, this)
    }

    override
    fun onNameError() {

    }

    override fun onEmailError() {
        registerContract.apply {
            setEmailError()
            hideProgress()
        }
    }

    override fun onPasswordError() {
        registerContract.apply {
            setPasswordError()
            hideProgress()
        }
    }

    override fun onSuccess(email: String, password: String, name: String) {
        registerInteractor.signUpPresenter(email, password, name, this)


    }

    override fun onNavigate() {
        registerContract.navigateToHome()
    }



    override fun toast(toast: String) {
        registerContract.toast(toast)
    }

    override fun hideProgress() {
        registerContract.hideProgress()

    }
}