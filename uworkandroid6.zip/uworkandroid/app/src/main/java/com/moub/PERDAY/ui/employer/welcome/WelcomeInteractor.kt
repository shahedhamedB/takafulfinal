package com.moub.PERDAY.ui.employer.welcome

class WelcomeInteractorEmployer {
    interface OnWelcomeFinishedListener {

        fun onSuccess()
        fun onNavigateHome()
        fun onNavigateRegister()
    }

    fun verification(listener: OnWelcomeFinishedListener) {

        listener.onNavigateRegister()
        }

}
