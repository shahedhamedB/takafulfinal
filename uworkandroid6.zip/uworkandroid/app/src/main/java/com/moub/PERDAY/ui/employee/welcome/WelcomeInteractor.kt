package com.moub.PERDAY.ui.employee.welcome

class WelcomeInteractor {
    interface OnWelcomeFinishedListener {

        fun onSuccess()
        fun onNavigateHome()
        fun onNavigateRegister()
    }

    fun verification(listener: OnWelcomeFinishedListener) {

        listener.onNavigateRegister()
        }

}
