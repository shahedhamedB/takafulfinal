package com.moub.PERDAY.ui.base

import android.Manifest
import android.R
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseException
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import com.moub.PERDAY.ui.employee.welcome.WelcomeActivity
import com.moub.PERDAY.utils.AppLogger
import java.util.concurrent.TimeUnit

open class BaseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    fun getLocation(logText: (Double, Double) -> Unit) {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
                != PackageManager.PERMISSION_GRANTED
            ) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(
                        this,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    )
                ) {
                } else {
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                        1
                    )
                }
            } else {
            }
        } else {
            try {
                val location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                val longitude = location.longitude
                val latitude = location.latitude
                logText(longitude, latitude)
            } catch (e: Exception) {
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>, grantResults: IntArray
    ) {
        when (requestCode) {
            1 -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {

                } else {

                }
                return
            }
            else -> {
            }
        }
    }

    fun baseSpinner(ArrayName: Array<String>, spinner: Spinner, onClick :(String) -> Unit) {
        val adapter = ArrayAdapter(this, R.layout.simple_spinner_dropdown_item
            , ArrayName)
        spinner.adapter = adapter

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(adapterView: AdapterView<*>, view: View, i: Int, l: Long) {
//                Toast.makeText(this@BaseActivity, ArrayName[i], Toast.LENGTH_SHORT).show()
                val data = ArrayName[i]
                onClick(ArrayName[i])
            }

            override fun onNothingSelected(adapterView: AdapterView<*>) {
            }
        }
    }


    lateinit var mCallbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks
    lateinit var mAuth: FirebaseAuth
    var verificationId = ""


    fun VerficationPhone(
        verifiTxt: EditText,
        phnNoTxt: EditText,
        progress: ProgressBar,
        veriBtn: Button,
        getCode: Button
    ) {
        mAuth = FirebaseAuth.getInstance()
        veriBtn.setOnClickListener { view: View? ->
            progress.visibility = View.VISIBLE
            verify(phnNoTxt, progress)
        }
        getCode.setOnClickListener { view: View? ->
            progress.visibility = View.VISIBLE
            authenticate(verifiTxt)
        }
    }


    private fun verificationCallbacks(progress: ProgressBar) {
        mCallbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                progress.visibility = View.INVISIBLE
                signIn(credential)
            }

            override fun onVerificationFailed(p0: FirebaseException?) {
                AppLogger.toast(this@BaseActivity, "Faild Verfiy")
            }

            override fun onCodeSent(verfication: String?, p1: PhoneAuthProvider.ForceResendingToken?) {
                super.onCodeSent(verfication, p1)
                verificationId = verfication.toString()
                progress.visibility = View.INVISIBLE
            }

        }
    }
    private fun verify(phnNoTxt: EditText, progress: ProgressBar) {

        verificationCallbacks(progress)

        val phnNo = phnNoTxt.text.toString()

        PhoneAuthProvider.getInstance().verifyPhoneNumber(
            phnNo,
            60,
            TimeUnit.SECONDS,
            this,
            mCallbacks
        )
    }

    private fun signIn(credential: PhoneAuthCredential) {
        mAuth.signInWithCredential(credential)
            .addOnCompleteListener { task: Task<AuthResult> ->
                if (task.isSuccessful) {
                    AppLogger.toast(this, "Logged in Successfully :)")
                    WelcomeActivity.start(this)
                    finish()
                }
            }
    }

    private fun authenticate(verifiTxt: EditText) {

        val verifiNo = verifiTxt.text.toString()

        val credential: PhoneAuthCredential = PhoneAuthProvider.getCredential(verificationId, verifiNo)

        signIn(credential)

    }


}
