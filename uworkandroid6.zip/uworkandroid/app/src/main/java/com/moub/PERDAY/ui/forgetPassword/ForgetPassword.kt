package com.moub.PERDAY.ui.forgetPassword

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.moub.PERDAY.R
import com.moub.PERDAY.ui.employee.auth.loign.LoginActivity
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_forget_password.*

class ForgetPassword : AppCompatActivity(), ForgetPasswordView {
    override fun showProgress() {
        progressBar.visibility = View.VISIBLE
    }

    override fun hideProgress() {
        progressBar.visibility = View.GONE
    }

    override fun setEmailError() {
        email.error = "Your Email Cannot Be Empty"
    }

    override fun navigateToHome() {
        LoginActivity.start(this)
    }

    override fun toast(message: String) {
        AppLogger.toast(this, message)
    }

    private val presenter = ForgetPasswordPresenter(this, ForgetPasswordInteractor())


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_password)
        restPassword.setOnClickListener { presenter.restPAssword(email.text.toString()) }

    }


    companion object {
        fun start(context: Context) {
            val intent = Intent(context, ForgetPassword::class.java)
            context.startActivity(intent)
        }
    }

}
