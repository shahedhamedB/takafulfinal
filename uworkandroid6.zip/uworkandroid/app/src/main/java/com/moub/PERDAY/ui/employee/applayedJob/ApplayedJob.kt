package com.moub.PERDAY.ui.employee.applayedJob

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.model.EmployeeWorkInfo
import com.moub.PERDAY.ui.employee.jobList.JobList
import com.moub.PERDAY.utils.AppLogger
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_applayed_job.*
import kotlinx.android.synthetic.main.applaied_dialog.*
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import kotlin.collections.ArrayList

class ApplayedJob : AppCompatActivity() {
    private var ts: String = ""
    private var jobTitle = CacheManager.instance.getJobTitle()
    private var legalName = CacheManager.instance.getlegalName()
    private var description = CacheManager.instance.getDescription()
    private var day = CacheManager.instance.perDay()
    private var week = CacheManager.instance.perWeek()
    private var location = CacheManager.instance.getLocation()
    private var locationEmployee = CacheManager.instance.getCountryEmployee()
    private var edu = CacheManager.instance.educational()
    private var employerId = CacheManager.instance.getEmployerId()
    private var jobCategory = CacheManager.instance.category()
    private var idEmployer = CacheManager.instance.getEmployerId()
    private var employeeName = CacheManager.instance.getUserName()
    private var experianceEmployee = CacheManager.instance.getYearsOfExperience()
    private var educationalLevelEmployee = CacheManager.instance.getEducationalLevel()
    private var DayCheckBoxEmployee: ArrayList<String> = ArrayList()
    private var fieldExperiance: ArrayList<String> = ArrayList()
    private var numHours: ArrayList<Int> = ArrayList()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_applayed_job)
        getDataArray()
        time()
        getDataFromListJob()
        applyBtn.setOnClickListener { DialogOffer() }


    }

    private fun DialogOffer() {

        val dialog = Dialog(this)
        dialog.setContentView(R.layout.applaied_dialog)
        dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.confirmBtn.setOnClickListener {
            SendApplaied()
            dialog.cancel()
            AppLogger.toast(this, "Your order has been successfully sent, we wish you a successful job")
            JobList.start(this)
            finish()
        }
        dialog.cancelBtn.setOnClickListener {
            dialog.cancel()
        }
    }

    private fun SendApplaied() {

        fireStoreManager.saveApplaiedJobEmployee(
            idEmployer,
            employeeName,
            experianceEmployee,
            locationEmployee,
            educationalLevelEmployee,
            DayCheckBoxEmployee,
            numHours,
            fieldExperiance,
            ts,this.legalName,this.jobTitle,this.location,this.jobCategory
        )

    }

    fun getDataArray() {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val docRef = FirebaseFirestore.getInstance().collection("EmployeeWorkInfo").document(id)
        docRef.get().addOnSuccessListener { documentSnapshot ->
            val data = documentSnapshot.toObject(EmployeeWorkInfo::class.java)
            this.fieldExperiance = data!!.fieldOfExperiance
            this.DayCheckBoxEmployee = data.weekDaysAvalability
            this.numHours = data.dayHours

        }
    }


    fun time() {
        val current = LocalDateTime.now()

        val formatter = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
        val formatted = current.format(formatter)
        ts = formatted

    }

    fun getDataFromListJob() {

        val logo = CacheManager.instance.getLogo()
        try {
            Picasso.get().load(logo).into(imageView21)
        } catch (e: Exception) {
        }
        EmployeePhoto.text = jobTitle
        nameLegal.text = legalName
        textView67.text = description
        textView65.text = day
        textView64.text = week
        textView66.text = location

        fireStoreManager.ApplayJobEmployee(
            employerId, legalName, jobTitle, location,
            edu,
            week,
            day,
            jobCategory,
            description,
            logo,
            ts
        )
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, ApplayedJob::class.java)
            context.startActivity(intent)
        }
    }
}
