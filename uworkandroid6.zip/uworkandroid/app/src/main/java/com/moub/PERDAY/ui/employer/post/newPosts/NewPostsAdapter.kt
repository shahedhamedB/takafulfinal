package com.moub.PERDAY.ui.employer.post.newPosts

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.moub.PERDAY.R
import com.moub.PERDAY.model.PostModel
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.item_job_list.view.*

class NewPostsAdapter(
    private val items: MutableList<PostModel>, val context: Context, val onClick: (String, String) -> Unit
) : RecyclerView.Adapter<NewPostsAdapter.viewHolder>() {
    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        val model = items[position]
        holder.jobTitle.text = model.jobTilte
        holder.companyName.text = model.legalName
        holder.location.text = model.location
        holder.jobTime.text = model.week

        onClick(model.id, items.size.toString())

        holder.numWorkers.text = model.numWorkers

        try {
            Picasso.get().load(model.logo).into(holder.LogoCompany)
        } catch (e: Exception) {
        }

        holder.love.setOnClickListener {
            holder.love.setBackgroundResource(R.drawable.heat)
        }

    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): viewHolder {
        return viewHolder(LayoutInflater.from(context).inflate(R.layout.item_job_list, p0, false))
    }

    override fun getItemCount(): Int {
        return items.size

    }


    class viewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val jobTitle = view.jobTitle
        val companyName = view.legalName
        val location = view.location
        val jobTime = view.workTime
        val mediacardview = view.carView
        val LogoCompany = view.logo
        val numWorkers = view.numforWork
        val love = view.love
    }
}