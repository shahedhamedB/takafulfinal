package com.moub.PERDAY.ui.employer.post

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.moub.PERDAY.ui.employer.post.lastPosts.LastPosts
import com.moub.PERDAY.ui.employer.post.newPosts.NewPosts

class PostAdapter (val context: Context, fm: FragmentManager): FragmentPagerAdapter(fm) {
    var itemsCount = 2
    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> NewPosts()
            else -> {
                return LastPosts()
            }
        }
    }

    override fun getCount(): Int {
        return itemsCount
    }

    override fun getPageTitle(position: Int): CharSequence {
        return when (position) {
            0 -> "New Posts"
            else -> {
                return "Last Posts"
            }
        }
    }
}