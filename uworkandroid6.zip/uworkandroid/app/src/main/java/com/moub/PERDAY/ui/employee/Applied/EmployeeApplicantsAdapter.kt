package com.moub.PERDAY.ui.employee.Applied

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.moub.PERDAY.R
import com.moub.PERDAY.model.saveApplaiedEmployeeModel
import kotlinx.android.synthetic.main.new_applicants.view.*

class EmployeeApplicantsAdapter(
private val items: MutableList<saveApplaiedEmployeeModel>, val context: Context, val onClick: (ImageView,String, String,String) -> Unit
) : RecyclerView.Adapter<EmployeeApplicantsAdapter.viewHolder>() {
    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        val model = items[position]
        holder.Experiance.text = model.legalName
        holder.EmployeeName.text = model.jobTitle
        holder.location.text = model.locationEmployer
        holder.jobTime.visibility = View.GONE
        holder.numWorkers.text = model.time
        holder.imageView19.visibility = View.GONE
        holder.settings.setOnClickListener {

        }
        onClick(holder.settings,model.id,items.size.toString(),model.idEmployer)

    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): viewHolder {
        return viewHolder(LayoutInflater.from(context).inflate(R.layout.new_applicants, p0, false))
    }

    override fun getItemCount(): Int {
        return items.size

    }


    class viewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val EmployeeName = view.EmployeeName
        val Experiance = view.ExperianceApplicants
        val location = view.EmployeeLocation
        val jobTime = view.workTimeEmployee
        val mediacardview = view.carViewApplicants
        val LogoCompany = view.EmployeePhoto
        val numWorkers = view.time
        val settings = view.settings
        val imageView19 = view.imageView19
    }
}