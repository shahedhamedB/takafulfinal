package com.moub.PERDAY.ui.splash

interface SplashContract {
    fun navigateToHome()
    fun navigateToRegister()
    fun onNavigateEmployerHome()
    fun onNavigateStatus()


}