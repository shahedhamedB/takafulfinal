package com.moub.PERDAY.ui.forgetPassword

class ForgetPasswordPresenter(
    val forgetPasswordView: ForgetPasswordView,
    val forgetPasswordInteractor: ForgetPasswordInteractor
) :
    ForgetPasswordInteractor.OnResetFinishedListener {
    override fun onEmailError() {
        forgetPasswordView.setEmailError()
    }

    fun restPAssword(email: String) {
        forgetPasswordInteractor.restPassword(email, this)
    }

    override fun onSuccess(email: String) {
        forgetPasswordInteractor.Rest(email, this)
    }

    override fun onNavigate() {
        forgetPasswordView.navigateToHome()
    }

    override fun toast(toast: String) {
        forgetPasswordView.toast(toast)
    }

    override fun hideProgress() {
        forgetPasswordView.hideProgress()
    }


}