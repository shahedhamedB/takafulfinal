package com.moub.PERDAY.ui.employer.applicants.lastApplicants


import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

import com.moub.PERDAY.R
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.model.saveApplaiedEmployeeModel
import com.moub.PERDAY.ui.employer.Jobs.JobsAdapter
import com.moub.PERDAY.ui.employer.applicants.newApplicants.NewApplicantsAdapter
import com.moub.PERDAY.ui.employer.rateEmployee.Rate
import com.moub.PERDAY.utils.AppConstants
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.fragment_last_applicants2.*
import kotlinx.android.synthetic.main.settings_dialog.*

class LastApplicants : Fragment() {

    private var RequestId :String = ""
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_last_applicants2, container, false)

        getComment {
            lastApplicantsEmployerRecyclerView.adapter =
                LastApplicantsAdapter(it,activity!!) {
                    }
                }

        return view
    }





    fun getComment(onComplete: (MutableList<saveApplaiedEmployeeModel>) -> Unit): ListenerRegistration {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = FirebaseFirestore.getInstance()
            .collection("employerUsers")
            .document(id) // idEmployer
            .collection("employee").whereEqualTo("status", AppConstants.Status.ACCEPTED)

        return doc.addSnapshotListener { querySnapshot, firebaseExeption ->
            Log.w("firebaseExeption", "" + firebaseExeption)
            Log.i("firebaseExeption", "" + querySnapshot)
            onComplete(querySnapshot!!.toObjects(saveApplaiedEmployeeModel::class.java))

        }
    }

    private fun DialogOffer() {

        val dialog = Dialog(activity!!)

        dialog.setContentView(R.layout.settings_dialog)
        dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.reportBtn.setOnClickListener {
            dialog.cancel()
            AppLogger.toast(activity!!, "Your complaint has been successfully submitted")
        }
        dialog.deleteBtn.setOnClickListener {
            //            delete()
            AppLogger.toast(activity!!, "This request has been successfully deleted")
            dialog.cancel()
        }
    }


}
