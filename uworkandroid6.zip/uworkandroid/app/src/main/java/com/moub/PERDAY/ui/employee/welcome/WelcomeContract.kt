package com.moub.PERDAY.ui.employee.welcome

import android.widget.TextView

interface WelcomeContract {
    fun navigateToHome()
    fun navigateToRegister()
    fun animationTxt(text: TextView)
}