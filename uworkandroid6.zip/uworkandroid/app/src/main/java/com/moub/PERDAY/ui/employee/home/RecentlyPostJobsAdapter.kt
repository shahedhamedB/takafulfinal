package com.moub.PERDAY.ui.employee.home

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.model.PostModel
import com.moub.PERDAY.ui.employee.applayedJob.ApplayedJob
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.item_recently_add_job.view.*

class RecentlyPostJobsAdapter(
    private val items: MutableList<PostModel>, val context: Context, val onClick: (String,Int) -> Unit
) : RecyclerView.Adapter<RecentlyPostJobsAdapter.viewHolder>() {
    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        val model = items[position]
        holder.jobTitle.text = model.jobTilte
        holder.companyName.text = model.legalName
        holder.location.text = model.location
        holder.jobTime.text = model.week
        holder.mediacardview.setOnClickListener{
            ApplayedJob.start(context)
            Intent(context, ApplayedJob::class.java)
            CacheManager.instance.setLogo(model.logo)
            CacheManager.instance.setJobTitle(model.jobTilte)
            CacheManager.instance.setlegalName(model.legalName)
            CacheManager.instance.setDescription(model.description)
            CacheManager.instance.setperWeek(model.week)
            CacheManager.instance.setperDay(model.day)
            CacheManager.instance.setLocation(model.location)
            CacheManager.instance.seteducational(model.educationalLevel)
            CacheManager.instance.setpayment(model.payment)
            CacheManager.instance.setcategory(model.jobCategory)
            CacheManager.instance.setEmployerId(model.id)
            onClick(model.id, items.size)


        }
        holder.numWorkers.text = model.numWorkers

        try {
            Picasso.get().load(model.logo).into(holder.LogoCompany)
        } catch (e: Exception) {
        }


    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): viewHolder {
        return viewHolder(LayoutInflater.from(context).inflate(R.layout.item_recently_add_job, p0, false))
    }

    override fun getItemCount(): Int {
        CacheManager.instance.setSize(items.size)
        return items.size


    }


    class viewHolder(view: View) : RecyclerView.ViewHolder(view) {
        // Holds the TextView that will add each animal to
        val jobTitle = view.EmployeePhoto
        //    val imageService = view.imageService
        val companyName = view.companyName
        val location = view.location
        val jobTime = view.jobTime
        val mediacardview = view.media_card_view
        val LogoCompany = view.LogoCompany
        val numWorkers = view.num_worker
    }
}
