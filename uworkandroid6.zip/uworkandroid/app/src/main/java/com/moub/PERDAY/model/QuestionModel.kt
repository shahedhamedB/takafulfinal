package com.moub.PERDAY.model

class QuestionModel(val employerId:String,val employeeID:String,val question:String,val answer:String,val requestId:String,val time:String,val employeeName:String,val answerStatus:String) {
    constructor() : this("","","","","","","","")
}