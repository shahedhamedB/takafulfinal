package com.moub.PERDAY.ui.employee.main

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.moub.PERDAY.ui.employee.home.Home
import com.moub.PERDAY.ui.employee.Applied.Applied
import com.moub.PERDAY.ui.employee.schedule.Schedule

class MainTabsAdapter(val context: Context, fm: FragmentManager) : FragmentPagerAdapter(fm) {

    var itemsCount = 3
    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> Home()
            1 -> Applied()
            else -> {
                return Schedule()
            }
        }
    }

    override fun getCount(): Int {
        return itemsCount
    }

    override fun getPageTitle(position: Int): CharSequence {
        return when (position) {
            0 -> "Home"
            1 -> "Applied"
            else -> {
                return "Schedule"
            }
        }
    }

}