package com.moub.PERDAY.model

class EmployeePersonalInfo (
    val id: String, val languagesEmployee: String, val material: String, val helth: String,
    val familySize: String,
    val familyWork: String,
    val year: String,
    val month:String,
    val day: String,
    val location :String
) {
    constructor() : this("", "", "", "", "", "", "", "","","")
}