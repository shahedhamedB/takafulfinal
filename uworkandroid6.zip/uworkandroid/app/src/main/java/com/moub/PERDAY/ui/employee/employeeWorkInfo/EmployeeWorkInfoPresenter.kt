package com.moub.PERDAY.ui.employee.employeeWorkInfo

import android.annotation.SuppressLint
import android.content.Context
import android.widget.CheckBox
import android.widget.Spinner
import androidx.recyclerview.widget.RecyclerView
import com.moub.PERDAY.R
import com.moub.PERDAY.utils.AppLogger

class EmployeeWorkInfoPresenter(val contract: EmployeeWorkInfoContract) {
    interface listenerFunctions {
        fun setCheckError()
        fun onSuccess()
    }

    fun checklistener(
        check1: CheckBox,
        check2: CheckBox,
        check3: CheckBox,
        check4: CheckBox,
        listener: listenerFunctions
    ) {
        if (check1.isChecked or check2.isChecked or check3.isChecked or check4.isChecked) {
            listener.onSuccess()
        } else {
            listener.setCheckError()
        }
    }

    fun spinner(spinner: Spinner, language: Array<String>, postion: (String) -> Unit) {
        contract.spinner(language, spinner) { oncick ->
            postion(oncick)
        }
    }

    @SuppressLint("ResourceAsColor")
    fun numHoursFun(context: Context, numRecycler: RecyclerView,data:(ArrayList<Int>)->Unit) {
        val numSelect = ArrayList<Int>()
        val num: Array<String> = context.resources.getStringArray(R.array.numberHours)
        numRecycler.adapter = WorkInfoAdapter(num.toCollection(ArrayList())) { txtNumber, Posetion ->

            val position = Posetion + 1
            val pos = numSelect.find { index -> index == position }
            if (pos == null) {
                numSelect.add(position)
                txtNumber.setBackgroundResource(R.drawable.num_button_pressed)
                txtNumber.setTextColor(R.color.blue)
            } else {
                numSelect.remove(position)
                AppLogger.toast(context, "$position")
                txtNumber.setBackgroundResource(R.drawable.edit_text_forget_password)
                txtNumber.setTextColor(R.color.black)
            }
            data(numSelect)
            AppLogger.toast(context, "$pos TestActivity\nnumSelect = $numSelect")

        }
    }




}
