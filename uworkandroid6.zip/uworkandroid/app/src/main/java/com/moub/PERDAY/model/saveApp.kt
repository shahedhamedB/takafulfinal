package com.moub.PERDAY.model

class saveApp(
    val id: String,
    val name: String,
    val number: Int
) {
    constructor() : this("", "", 123)
}