package com.moub.PERDAY.managers

class CacheManager private constructor() {
    private val mSharedPreference: SharedPreferencesManager by lazy { SharedPreferencesManager() }

    private var token: String? = null
    private var imageUrl: String = ""
    private var accessToken: String = ""
    private var refreshToken: String = ""
    private var userName: String = ""
    private var select:Int = 1
    private var Sector:String = ""
    private var location: String = ""
    private var educational: String = ""
    private var perWeek: String = ""
    private var perDay: String = ""
    private var experiance: String = ""
    private var category: String = ""
    private var payment: String = ""
    private var lonEmployer: String = ""
    private var latEmployer: String = ""
    private var countryEmployer: String = ""
    private var lonEmployee: String = ""
    private var latEmployee: String = ""
    private var countryEmployee: String = ""
    private var employeeId: String = ""
    private var employer: String = ""
    private var legalName: String = ""
    private var logo: String = ""
    private var loginType: String = ""
    private var checkEmployerLogin: String = ""
    private var checkEmployee: String = ""
    private var jobTitle: String = ""
    private var description: String = ""
    private var language: String = ""
    private var material: String = ""
    private var helth: String = ""
    private var familySize: String = ""
    private var familyWork: String = ""
    private var birthdayYear: String = ""
    private var birthdayMonth: String = ""
    private var birthdayDay: String = ""
    private var YearsOfExperience: String = ""
    private var EducationalLevel: String = ""
    private var requestIdNotification: String = ""
    private var Size: Int = 0




    val isLoggedIn: Boolean
        get() = !getToken().isNullOrBlank()

    init {
        requestIdNotification = mSharedPreference.getStringPreferences("requestIdNotification","")!!
        token = mSharedPreference.getStringPreferences("token", "")
        accessToken = mSharedPreference.getStringPreferences("accessToken", "")!!
        refreshToken = mSharedPreference.getStringPreferences("refreshToken", "")!!
        checkEmployerLogin = mSharedPreference.getStringPreferences("employer", "")!!
        checkEmployee = mSharedPreference.getStringPreferences("checkEmployee", "")!!
        Size = mSharedPreference.getIntPreferences("Size", 0)
        logo = mSharedPreference.getStringPreferences("logo","")!!
        lonEmployee = mSharedPreference.getStringPreferences("longEmployee","")!!
        latEmployee =  mSharedPreference.getStringPreferences("latEmployee","")!!
        lonEmployer =  mSharedPreference.getStringPreferences("long","")!!
        latEmployer =  mSharedPreference.getStringPreferences("lat","")!!
        userName =  mSharedPreference.getStringPreferences("userName","")!!
        select =  mSharedPreference.getIntPreferences("select",0)

    }

    fun clearAll() {
        mSharedPreference.clearPreference()
        mInstance = CacheManager()
        token = ""
        imageUrl = ""
        checkEmployerLogin = ""
    }

    //------------ Get Cache Value ------------//

    // TODO: Get Cache Value

    fun getImageUrl(): String {
        return imageUrl
    }



    fun getEducationalLevel(): String {
        return EducationalLevel
    }

    fun getRequestIdNotification(): String {
        return requestIdNotification
    }

    fun getSize(): Int {
        return Size
    }

    fun getYearsOfExperience(): String {
        return YearsOfExperience
    }

    fun getJobTitle(): String {
        return jobTitle
    }

    fun getmaterial(): String {
        return material
    }

    fun getHelth(): String {
        return helth
    }

    fun getfamilySize(): String {
        return familySize
    }fun getCountryEmployee(): String {
        return countryEmployee
    }

    fun getfamilyWork(): String {
        return familyWork
    }

    fun getLanguagePersonalInfo(): String {
        return language
    }

    fun getBirthdayYear(): String {
        return birthdayYear
    }

    fun getBirthdayMonth(): String {
        return birthdayMonth
    }

    fun getBirthdayDay(): String {
        return birthdayDay
    }

    fun getDescription(): String {
        return description
    }

    fun getCheckEmployer(): String {
        return checkEmployerLogin
    }

    fun getCheckEmployee(): String {
        return checkEmployee
    }

    fun getLoginType(): String {
        return loginType
    }

    fun getLogo(): String {
        return logo
    }

    fun getlegalName(): String {
        return legalName
    }

    fun getcountry(): String {
        return countryEmployer
    }

    fun getEmployeeId(): String {
        return employeeId
    }

    fun getEmployerId(): String {
        return employer
    }

    fun educational(): String {
        return educational
    }

    fun perWeek(): String {
        return perWeek
    }

    fun experiance(): String {
        return experiance
    }

    fun perDay(): String {
        return perDay
    }

    fun category(): String {
        return category
    }

    fun getPayment(): String {
        return payment
    }

    fun getLongEmployer(): String {
        return lonEmployer
    }

    fun getLatEmployer(): String {
        return latEmployer
    }
    fun getLongEmployee(): String {
        return lonEmployee
    }

    fun getLatEmployee(): String {
        return latEmployee
    }

    fun getToken(): String? {
        return token
    }

    fun getAccessToken(): String {
        return accessToken
    }

    fun getRefreshToken(): String {
        return refreshToken
    }

    fun getUserName(): String {
        return userName
    }

    fun getSelect():Int{
        return select
    }
    fun getSector():String{
        return Sector
    }

    fun getLocation(): String {
        return location
    }

    //------------ Set Cache Value ------------//

    fun setLanguageEmployee(language: String) {
        this.language = language
        mSharedPreference.setStringPreferences("language", language)
    }



    fun setEducationalLevel(EducationalLevel: String) {
        this.EducationalLevel = EducationalLevel
        mSharedPreference.setStringPreferences("EducationalLevel", EducationalLevel)
    }

    fun setRequestIdNotification(requestIdNotification: String) {
        this.requestIdNotification = requestIdNotification
        mSharedPreference.setStringPreferences("requestIdNotification", requestIdNotification)
    }

    fun setSize(Size: Int) {
        this.Size = Size
        mSharedPreference.setIntPreferences("Size", Size)
    }

    fun setYearsOfExperience(YearsOfExperience: String) {
        this.YearsOfExperience = YearsOfExperience
        mSharedPreference.setStringPreferences("YearsOfExperience", YearsOfExperience)
    }

    fun setBirthdayYear(year: String) {
        this.birthdayYear = year
        mSharedPreference.setStringPreferences("year", year)
    }

    fun setBirthdayMonth(month: String) {
        this.birthdayMonth = month
        mSharedPreference.setStringPreferences("month", month)
    }

    fun setCountryEmployee(CountryEmployee: String) {
        this.countryEmployee = CountryEmployee
        mSharedPreference.setStringPreferences("CountryEmployee", CountryEmployee)
    }
    fun setHelth(helth: String) {
        this.helth = helth
        mSharedPreference.setStringPreferences("helth", helth)
    }

    fun setBirthdayDay(day: String) {
        this.birthdayDay = day
        mSharedPreference.setStringPreferences("day", day)
    }

    fun setMaterial(material: String) {
        this.material = material
        mSharedPreference.setStringPreferences("material", material)
    }

    fun setFamilySize(FamilySize: String) {
        this.familySize = FamilySize
        mSharedPreference.setStringPreferences("FamilySize", FamilySize)
    }

    fun setFamilyWork(FamilyWork: String) {
        this.familyWork = FamilyWork
        mSharedPreference.setStringPreferences("FamilyWork", FamilyWork)
    }

    fun setLocation(location: String) {
        this.location = location
        mSharedPreference.setStringPreferences("location", location)
    }

    fun setDescription(descrption: String) {
        this.description = descrption
        mSharedPreference.setStringPreferences("descrption", descrption)
    }

    fun setJobTitle(jobTitle: String) {
        this.jobTitle = jobTitle
        mSharedPreference.setStringPreferences("jobTitle", jobTitle)
    }

    fun setCheckEmployer(employer: String) {
        this.checkEmployerLogin = employer
        mSharedPreference.setStringPreferences("employer", employer)
    }

    fun setCheckEmployee(checkEmployee: String) {
        this.checkEmployee = checkEmployee
        mSharedPreference.setStringPreferences("checkEmployee", checkEmployee)
    }

    fun setLogo(logo: String) {
        this.logo = logo
        mSharedPreference.setStringPreferences("logo", logo)
    }

    fun setLoginType(loginType: String) {
        this.loginType = loginType
        mSharedPreference.setStringPreferences("loginType", loginType)
    }

    fun setlegalName(legalName: String) {
        this.legalName = legalName
        mSharedPreference.setStringPreferences("legalName", legalName)
    }

    fun setEmployeeId(employee: String) {
        this.employeeId = employee
        mSharedPreference.setStringPreferences("employeeId", employee)
    }

    fun setEmployerId(employer: String) {
        this.employer = employer
        mSharedPreference.setStringPreferences("employer", employer)
    }

    fun setLongEmployer(long: String) {
        this.lonEmployer = long
        mSharedPreference.setStringPreferences("long", long)
    }

    fun setLatEmployer(lat: String) {
        this.latEmployer = lat
        mSharedPreference.setStringPreferences("lat", lat)
    }
    fun setLongEmployee(long: String) {
        this.lonEmployee = long
        mSharedPreference.setStringPreferences("longEmployee", long)
    }

    fun setLatEmployee(lat: String) {
        this.latEmployee = lat
        mSharedPreference.setStringPreferences("latEmployee", lat)
    }

    fun seteducational(educational: String) {
        this.educational = educational
        mSharedPreference.setStringPreferences("educational", educational)
    }

    fun setexperiance(experiance: String) {
        this.experiance = experiance
        mSharedPreference.setStringPreferences("experiance", experiance)
    }

    fun setcountry(country: String) {
        this.countryEmployer = country
        mSharedPreference.setStringPreferences("country", country)
    }

    fun setpayment(payment: String) {
        this.payment = payment
        mSharedPreference.setStringPreferences("getPayment", payment)
    }

    fun setcategory(category: String) {
        this.category = category
        mSharedPreference.setStringPreferences("category", category)
    }

    fun setperWeek(perWeeks: String) {
        this.perWeek = perWeeks
        mSharedPreference.setStringPreferences("perWeek", perWeeks)
    }

    fun setperDay(perDay: String) {
        this.perDay = perDay
        mSharedPreference.setStringPreferences("perDay", perDay)
    }

    fun setImageUrl(imageUrl: String) {
        this.imageUrl = imageUrl
        mSharedPreference.setStringPreferences("imageUrl", imageUrl)
    }

    fun setAccessToken(accessToken: String) {
        this.accessToken = accessToken
        mSharedPreference.setStringPreferences("accessToken", accessToken)
    }

    fun setRefreshToken(refreshToken: String) {
        this.refreshToken = refreshToken
        mSharedPreference.setStringPreferences("refreshToken", refreshToken)
    }

    fun setToken(token: String) {
        this.token = token
        mSharedPreference.setStringPreferences("token", token)
    }

    fun setUserName(userName: String) {
        this.userName = userName
        mSharedPreference.setStringPreferences("userName", userName)
    }

    fun setSelect(select:Int){
        this.select = select
        mSharedPreference.setIntPreferences("select",select)
    }
    fun setSector(sector:String){
        this.Sector = sector
        mSharedPreference.setStringPreferences("sector",sector)
    }


    companion object {
        private var mInstance: CacheManager? = null

        val instance: CacheManager
            @Synchronized get() {
                if (mInstance == null) {
                    mInstance = CacheManager()
                }
                return mInstance!!
            }
    }

}