package com.moub.PERDAY.model

class PostModel(
    val requestId :String,
    val id: String, val legalName:String,val jobTilte: String, val numWorkers: String, val location: String,
    val educationalLevel: String,
    val week: String,
    val day: String,
    val experance:String,
    val jobCategory: String,
    val description:String,
    val payment :String,
    val logo :String
) {
    constructor() : this("","", "","", "", "", "", "", "", "","","","","")
}