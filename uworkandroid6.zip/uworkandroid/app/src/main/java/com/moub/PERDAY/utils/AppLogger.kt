package com.moub.PERDAY.utils

import android.content.Context
import android.util.Log
import android.widget.Toast

object AppLogger  {
    fun toast (context: Context, message:String ){
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
    fun log(tag:String,msg:String){
        Log.d(tag, msg)
    }

}