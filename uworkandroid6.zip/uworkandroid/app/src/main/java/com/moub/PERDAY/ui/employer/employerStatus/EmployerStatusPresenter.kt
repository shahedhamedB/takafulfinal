package com.moub.PERDAY.ui.employer.employerStatus

import android.widget.Spinner

class EmployerStatusPresenter(val contract: EmployerStatusContract) {

    fun spinner(spinner: Spinner, language:Array<String> ) {
        contract.spinner(language, spinner)
    }


}