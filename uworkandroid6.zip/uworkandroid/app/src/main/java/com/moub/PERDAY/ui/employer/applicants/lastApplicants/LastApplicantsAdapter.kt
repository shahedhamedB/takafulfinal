package com.moub.PERDAY.ui.employer.applicants.lastApplicants

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.moub.PERDAY.R
import com.moub.PERDAY.model.saveApplaiedEmployeeModel
import kotlinx.android.synthetic.main.new_applicants_employer.view.*

class LastApplicantsAdapter(
    private val items: MutableList<saveApplaiedEmployeeModel>, val context: Context, val onClick: () -> Unit
) : RecyclerView.Adapter<LastApplicantsAdapter.viewHolder>() {
    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        val model = items[position]
        holder.Experiance.text = model.experiance
        holder.EmployeeName.text = model.employeeName
        holder.location.text = model.location
        holder.jobTime.text = model.week.toString()
        holder.numWorkers.text = model.time
        holder.settings.setOnClickListener {

            holder.questionBtn.visibility =View.GONE
            holder.confirmEmployeeBtn.visibility =View.GONE

        }

        onClick()

    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): viewHolder {
        return viewHolder(
            LayoutInflater.from(
                context
            ).inflate(R.layout.new_applicants_employer, p0, false)
        )
    }

    override fun getItemCount(): Int {
        return items.size

    }


    class viewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val EmployeeName = view.EmployeeName2
        val Experiance = view.ExperianceApplicants2
        val location = view.EmployeeLocation2
        val jobTime = view.workTimeEmployee2
        val mediacardview = view.carViewApplicants2
        val LogoCompany = view.EmployeePhoto2
        val numWorkers = view.time2
        val settings = view.settings2
        val confirmEmployeeBtn = view.confirmEmployeeBtn
        val questionBtn = view.questionBtn
    }
}