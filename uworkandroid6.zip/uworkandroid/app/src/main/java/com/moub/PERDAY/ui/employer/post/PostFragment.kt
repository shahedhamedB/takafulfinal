package com.moub.PERDAY.ui.employer.post
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.moub.PERDAY.R
import kotlinx.android.synthetic.main.fragment_blank_fragment2.tabLayout
import kotlinx.android.synthetic.main.fragment_blank_fragment4.*

class PostFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_blank_fragment4, container, false)


        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        tabs()
    }

    fun tabs() {
        val fragmentAdapter = PostAdapter(activity!!, childFragmentManager)
        viewPagerPosts2.adapter = fragmentAdapter
        tabLayout.setupWithViewPager(viewPagerPosts2)
        viewPagerPosts2.offscreenPageLimit = 2
    }

}
