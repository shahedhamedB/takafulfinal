package com.moub.PERDAY.ui.employer.Jobs

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import com.moub.PERDAY.R
import com.moub.PERDAY.model.saveApplaiedEmployeeModel
import com.moub.PERDAY.model.setJobsEmployerModel
import kotlinx.android.synthetic.main.new_applicants_employer.view.*
import kotlinx.android.synthetic.main.submitted_applicants_employer.view.*

class JobsAdapter(
    private val items: MutableList<setJobsEmployerModel>, val context: Context, val onClick: (Button, String) -> Unit
) : RecyclerView.Adapter<JobsAdapter.viewHolder>() {
    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        val model = items[position]
        holder.Experiance.text = model.experiance
        holder.EmployeeName.text = model.employeeName
        holder.location.text = model.location
        holder.jobTime.text = model.week.toString()
        holder.numWorkers.text = model.time
        holder.settings.setOnClickListener {


        }

        onClick(holder.confirmEmployeeBtn2,model.requestId)

    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): viewHolder {
        return viewHolder(
            LayoutInflater.from(
                context
            ).inflate(R.layout.submitted_applicants_employer, p0, false)
        )
    }

    override fun getItemCount(): Int {
        return items.size

    }


    class viewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val EmployeeName = view.EmployeeName22
        val Experiance = view.ExperianceApplicants22
        val location = view.EmployeeLocation22
        val jobTime = view.workTimeEmployee22
        val mediacardview = view.carViewApplicants22
        val LogoCompany = view.EmployeePhoto22
        val numWorkers = view.time22
        val settings = view.settings22
        val confirmEmployeeBtn2 = view.confirmEmployeeBtn2
    }
}