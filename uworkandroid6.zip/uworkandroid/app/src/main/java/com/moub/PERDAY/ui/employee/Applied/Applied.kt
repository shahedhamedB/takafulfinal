package com.moub.PERDAY.ui.employee.Applied

import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.model.saveApplaiedEmployeeModel
import com.moub.PERDAY.utils.AppConstants
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.fragment_applied.*
import kotlinx.android.synthetic.main.settings_dialog.*

class Applied : Fragment() {

    private var employerId: String = CacheManager.instance.getEmployerId()
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view: View = inflater.inflate(R.layout.fragment_applied, container, false)

        getEmployeeApplicants {
            newApplicantsRecyclerView.adapter = EmployeeApplicantsAdapter(it, activity!!) { settings, onClick, size, idEmployer ->
                    AppLogger.toast(activity!!, onClick)
                    numJobs.text = size
                    settings.setOnClickListener { DialogOffer() }
//                    this.employerId = idEmployer
                }
        }
        return view
    }


    private fun DialogOffer() {

        val dialog = Dialog(activity!!)
        dialog.setContentView(R.layout.settings_dialog)
        dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.reportBtn.setOnClickListener {
            dialog.cancel()
            AppLogger.toast(activity!!, "Your complaint has been successfully submitted")
        }
        dialog.deleteBtn.setOnClickListener {
            AppLogger.toast(activity!!, "This request has been successfully deleted")
            dialog.cancel()
        }
    }

    fun getEmployeeApplicants(onComplete: (MutableList<saveApplaiedEmployeeModel>) -> Unit): ListenerRegistration {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = FirebaseFirestore.getInstance()
            .collection("employee")
            .document(id)
            .collection("Applicants").whereEqualTo("status", AppConstants.Status.PENDING)
        return doc.addSnapshotListener { querySnapshot, firebaseExeption ->
            Log.w("firebaseExeption", "" + firebaseExeption)
            Log.i("firebaseExeption", "" + querySnapshot)
            try {
                onComplete(querySnapshot!!.toObjects(saveApplaiedEmployeeModel::class.java))
            } catch (e: Exception) {
            }
        }
    }
}