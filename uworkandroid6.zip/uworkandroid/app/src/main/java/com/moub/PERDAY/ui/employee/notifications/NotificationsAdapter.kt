package com.moub.PERDAY.ui.employee.notifications

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.model.NotificationsItemsModel
import com.moub.PERDAY.ui.employee.questions.QuestionsEmployee
import com.moub.PERDAY.ui.employee.recentlyJob.RecentlyActivity
import kotlinx.android.synthetic.main.item_notifications.view.*

class NotificationsAdapter (
    private val items: MutableList<NotificationsItemsModel>, val context: Context, val onClick: (String) -> Unit
) : RecyclerView.Adapter<NotificationsAdapter.viewHolder>() {
    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        val model = items[position]
        val type = model.notificationType
        if (type == "question"){
            holder.pic_noti_type.setBackgroundResource(R.drawable.ic_conversation)
            holder.Time.text = model.time
            holder.txtNotiType.text = "You have received a new message"
            holder.txtAdviceNotiType.text = "Quickly answer the question to increase employment"
            onClick(model.requestId)
            holder.itemOnclick.setOnClickListener{
                val intent = Intent(context, QuestionsEmployee::class.java)
                intent.putExtra("requestId", model.requestId)
                intent.putExtra("requestIdNotification",model.requestIdNotification)
                CacheManager.instance.setRequestIdNotification(model.requestIdNotification)

                context.startActivity(intent)


            }
        }

        else if (type == "ConfirmEmployee"){
            holder.pic_noti_type.setBackgroundResource(R.drawable.ic_handshake)
            holder.Time.text = model.time
            holder.txtAdviceNotiType.text = "Congratulations, we have accepted your application for work"
            holder.txtNotiType.text = "You have been accepted to work"
            holder.itemOnclick.setOnClickListener {
                val intent = Intent(context, RecentlyActivity::class.java)
                intent.putExtra("requestId", model.requestId)
                context.startActivity(intent)
                val id = FirebaseAuth.getInstance().currentUser!!.uid
                FirebaseFirestore.getInstance().collection("employee").document(id).collection("Notifications").document(model.requestIdNotification).delete()
                    .addOnSuccessListener { Log.d("", "DocumentSnapshot successfully deleted!") }
                    .addOnFailureListener { e -> Log.w("", "Error deleting document", e) }
            }
        }
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): viewHolder {
        return viewHolder(LayoutInflater.from(context).inflate(R.layout.item_notifications, p0, false))
    }

    override fun getItemCount(): Int {
        return items.size

    }


    class viewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val pic_noti_type = view.pic_noti_type
        val txtNotiType = view.txtNotiType
        val Time = view.timeNoti
        val txtAdviceNotiType = view.txtAdviceNotiType
        val itemOnclick = view.itemOnclick


    }
}