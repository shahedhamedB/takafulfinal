package com.moub.PERDAY.ui.employer.applicants.newApplicants


import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.model.saveApplaiedEmployeeModel
import com.moub.PERDAY.ui.employer.questions.QuestionActivity
import com.moub.PERDAY.utils.AppConstants
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.confirm_employee_dialog.*
import kotlinx.android.synthetic.main.fragment_applied.numJobs
import kotlinx.android.synthetic.main.fragment_new_applicants.*
import kotlinx.android.synthetic.main.settings_dialog.*
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

class NewApplicants : Fragment() {
    private var ResquestId: String = ""
    private var jobTitle: String = ""
    private var employeeId: String = ""
    private var legalName: String = ""
    private var time: String = ""
    private var EmployeeName: String = ""
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.fragment_new_applicants, container, false)

        getComment {
            newApplicantsEmployerRecyclerView.adapter =
                NewApplicantsAdapter(
                    it,
                    activity!!
                ) { settings, onClick, size, requestId, confirmEmployeeBtn, JobTitle, LegalName, EmployeeId, questionBtn, employeeName ->
                    AppLogger.toast(activity!!, onClick)
                    numJobs.text = size
                    settings.setOnClickListener { DialogOffer() }
                    this.ResquestId = requestId
                    this.jobTitle = JobTitle
                    this.legalName = LegalName
                    this.employeeId = EmployeeId
                    this.EmployeeName = employeeName
                    confirmEmployeeBtn.setOnClickListener { confirmEmployeeDialog() }
                    questionBtn.setOnClickListener {
                        val intent = Intent(activity!!, QuestionActivity::class.java)
                        intent.putExtra("EmployeeId", this.employeeId)
                        intent.putExtra("EmployeeName", this.EmployeeName)
                        activity!!.startActivity(intent)
                    }
                }
            getTime()
        }
        return view
    }

    fun getTime(){
        val current = LocalDateTime.now()

        val formatter = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
        val formatted = current.format(formatter)
        this.time = formatted
    }

    private fun confirmEmployeeDialog() {
        val dialog = Dialog(activity!!)

        dialog.setContentView(R.layout.confirm_employee_dialog)
        dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.confirmBtn2.setOnClickListener {
            fireStoreManager.acceptApplicants(this.ResquestId)
            setJob()
            fireStoreManager.notiStatus(this.employeeId)
            fireStoreManager.createNotificationsItem(this.employeeId,"ConfirmEmployee",this.time)
//            AcceptEmployee()
            dialog.cancel()
            AppLogger.toast(activity!!, "This employee has been successfully selected")
        }
        dialog.cancelBtn2.setOnClickListener {
            dialog.cancel()
        }
    }


    fun setJob(){
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        FirebaseFirestore.getInstance().collection("employerUsers").document(id)
            .collection("Jobs").document(this.ResquestId).update("status","unComplete")
    }

    fun getComment(onComplete: (MutableList<saveApplaiedEmployeeModel>) -> Unit): ListenerRegistration {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = FirebaseFirestore.getInstance()
            .collection("employerUsers")
            .document(id) // idEmployer
            .collection("employee").whereEqualTo("status", AppConstants.Status.PENDING)
        return doc.addSnapshotListener { querySnapshot, firebaseExeption ->
            Log.w("firebaseExeption", "" + firebaseExeption)
            Log.i("firebaseExeption", "" + querySnapshot)
            onComplete(querySnapshot!!.toObjects(saveApplaiedEmployeeModel::class.java))

        }
    }

    private fun DialogOffer() {

        val dialog = Dialog(activity!!)

        dialog.setContentView(R.layout.settings_dialog)
        dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.reportBtn.setOnClickListener {
            dialog.cancel()
            AppLogger.toast(activity!!, "Your complaint has been successfully submitted")
        }
        dialog.deleteBtn.setOnClickListener {
            AppLogger.toast(activity!!, "This request has been successfully deleted")
            dialog.cancel()
        }
    }



//    fun AcceptEmployee() {
//        getPostData {
//            testadapter.adapter = testAdapter(it, activity!!) { location, logo, numWorkers, payment, week, experance,description,day,educationalLevel,jobCategory ->
//                fireStoreManager.acceptApplicantsForEmployee(employeeId,legalName,this.jobTitle,numWorkers,location,educationalLevel,week,day,experance,jobCategory,description,payment,logo)
//            }
//        }
//    }
//
//
//
//    fun getPostData(onComplete: (MutableList<PostModel>) -> Unit): ListenerRegistration {
//        val id = FirebaseAuth.getInstance().currentUser!!.uid
//        val doc = FirebaseFirestore.getInstance()
//            .collection("employerUsers").document(id).collection("posts")
//            .whereEqualTo("jobTilte", this.jobTitle)
//            .whereEqualTo("legalName", this.legalName)
//
//        return doc.addSnapshotListener { querySnapshot, firebaseExeption ->
//            Log.w("firebaseExeption", "" + firebaseExeption)
//            Log.i("firebaseExeption", "" + querySnapshot)
//            onComplete(querySnapshot!!.toObjects(PostModel::class.java))
//        }
//    }
companion object {
    fun start(context: Context) {
        val intent = Intent(context, NewApplicants::class.java)
        context.startActivity(intent)
    }
}

}
