package com.moub.PERDAY.ui.employer.questions

import android.content.Context
import android.widget.ProgressBar
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.utils.AppLogger

class QuestionPresenter {

    fun AskEmployee(context: Context,question:String,EmployeeId:String,Time:String,EmployeeName:String,ProgressBar: ProgressBar) {
        fireStoreManager.creatQuestion(EmployeeId,question,"",Time,EmployeeName,ProgressBar)
        AppLogger.toast(context,"Thank you , Your question has been successfully created")
    }
}