package com.moub.PERDAY.model

class QuestionModelRead(val Answer:String, val employeeID:String, val EmployeeName:String,val EmployerId:String, val Question:String,  val requestId:String, val Time:String) {
    constructor() : this("","","","","","","")
}