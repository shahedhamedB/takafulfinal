package com.moub.PERDAY.ui.base


import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.fragment.app.Fragment

@Suppress("NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
open class BaseFragment : Fragment() {
    fun baseSpinner(languages: Array<String>, spinner: Spinner) {
        val adapter = ArrayAdapter(activity, android.R.layout.simple_list_item_1, languages)
        spinner.adapter = adapter
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(adapterView: AdapterView<*>, view: View, i: Int, l: Long) {
                Toast.makeText(context, languages[i], Toast.LENGTH_SHORT).show()
                val data = languages[i]
            }

            override fun onNothingSelected(adapterView: AdapterView<*>) {
            }
        }
    }
    }