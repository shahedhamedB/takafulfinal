package com.moub.PERDAY.ui.employer.auth.login

interface LoginContract {
    fun showProgress()
    fun hideProgress()
    fun setEmailError()
    fun setPasswordError()
    fun navigateToHome()
    fun navigateRestPassword()
    fun toast(message:String)

}