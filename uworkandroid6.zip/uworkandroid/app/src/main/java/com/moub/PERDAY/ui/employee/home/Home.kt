package com.moub.PERDAY.ui.employee.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Spinner
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.model.PostModel
import com.moub.PERDAY.ui.base.BaseFragment
import com.moub.PERDAY.ui.employee.jobList.JobList
import com.moub.PERDAY.ui.employee.recentlyJob.RecentlyActivity
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.fragment_home.view.*

class Home : BaseFragment(), HomeContract {
    val presenter = HomePresenter(this)
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view: View = inflater.inflate(R.layout.fragment_home, container, false)

        getComment {
            recyclerView.adapter = RecentlyPostJobsAdapter(it, activity!!){ onClick ,size ->
                AppLogger.toast(activity!!,onClick)
                view.ApplayedNum.text = size.toString()

            }
        }


        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        setMilesSpinner()
        hereBtn()
        recent()
        ApplayedNum.text = CacheManager.instance.getSize().toString()

    }

    fun recent() {
        button.setOnClickListener {
            startActivity(Intent(activity, RecentlyActivity::class.java))
        }
    }

    fun hereBtn() {
        hereBtn?.setOnClickListener {
            startActivity(Intent(activity, JobList::class.java))
        }
    }

    override fun spinner(languages: Array<String>, spinner: Spinner) {
        baseSpinner(languages, spinner)
    }

    override fun setMilesSpinner() {
        presenter.spinner(milesSpinner, resources.getStringArray(R.array.nearbyJobs))
    }

    fun getComment(onComplete: (MutableList<PostModel>) -> Unit): ListenerRegistration {
        val doc = FirebaseFirestore.getInstance().collection("allPostsJob")
        return doc.addSnapshotListener { querySnapshot, _ ->
            onComplete(querySnapshot!!.toObjects(PostModel::class.java))
        }
    }
}


