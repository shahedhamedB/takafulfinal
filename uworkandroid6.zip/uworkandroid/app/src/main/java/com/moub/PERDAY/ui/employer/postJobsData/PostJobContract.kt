package com.moub.PERDAY.ui.employer.postJobsData

import android.widget.Spinner

interface PostJobContract {
    fun showProgressBar()
    fun hideProgressBar()
    fun setJobTitleError()
    fun setNumberOFWrkersError()
    fun setlocationSpinnerError()
    fun seteducationalLevelError()
    fun setperWeekSpinnerError()
    fun setperDaySpinnerError()
    fun setyearsOfExperiencePostError()
    fun setjobCategoryError()
    fun setjobDescriptionError()
    fun setpaymentSpinnerError()
    fun locationSpinner()
    fun educationalLevel()
    fun perWeekSpinner()
    fun perDaySpinner()
    fun yearsOfExperiencePost()
    fun jobCategory()
    fun paymentSpinner()
    fun spinner(languages:Array<String>,spinner: Spinner,position :(String)->Unit)





}