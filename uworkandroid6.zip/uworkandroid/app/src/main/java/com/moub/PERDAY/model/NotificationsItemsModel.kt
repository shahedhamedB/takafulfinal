package com.moub.PERDAY.model

 class NotificationsItemsModel(val employerId:String,val employeeId:String ,val notificationType:String , val requestId:String , val time:String,val requestIdNotification:String) {
    constructor() : this ("","","","","","")
}