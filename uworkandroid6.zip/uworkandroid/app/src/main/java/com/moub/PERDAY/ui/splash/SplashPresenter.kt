package com.moub.PERDAY.ui.splash

import android.content.Context

class SplashPresenter(val contract: SplashContract, val interactor: SplashInteractor) :
    SplashInteractor.OnSplashFinishedListener {
    override fun onNavigateStatus() {
        contract.onNavigateStatus()
    }

    override fun onNavigateEmployerHome() {
        contract.onNavigateEmployerHome()
    }


    fun userverification(context: Context) {
        interactor.verification(context ,this)
    }


    override fun onSuccess() {
    }

    override fun onNavigateEmployeeHome() {
        contract.navigateToHome()
    }

    override fun onNavigateRegister() {
        contract.navigateToRegister()
    }
}