package com.moub.PERDAY.ui.splash

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.moub.PERDAY.managers.CacheManager

class SplashInteractor {
    interface OnSplashFinishedListener {
        fun onSuccess()
        fun onNavigateEmployeeHome()
        fun onNavigateRegister()
        fun onNavigateEmployerHome()
        fun onNavigateStatus()



    }

    fun verification(context: Context, listener: OnSplashFinishedListener) {
        when {
            FirebaseAuth.getInstance().currentUser != null -> CheckUser(listener)
            else -> listener.onNavigateStatus()
        }
    }


    fun CheckUser(listener: OnSplashFinishedListener){
        val checkUser = CacheManager.instance.getCheckEmployee()

        when {
            checkUser == "Employee" -> listener.onNavigateEmployeeHome()
            checkUser == "Employer" -> listener.onNavigateEmployerHome()
            else -> listener.onNavigateStatus()
        }
    }
}


