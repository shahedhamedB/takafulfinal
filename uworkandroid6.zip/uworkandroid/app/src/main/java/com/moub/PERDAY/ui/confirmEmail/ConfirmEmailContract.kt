package com.moub.PERDAY.ui.confirmEmail

interface ConfirmEmailContract {

    fun showProgress()
    fun navigatToMain()
    fun navigateToData()
    fun hideProgress()
    fun setEmailError()
    fun toast(message:String)

}