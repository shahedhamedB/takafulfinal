package com.moub.PERDAY.ui.employee.recentlyJob

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.moub.PERDAY.ui.employee.recentlyJob.JobCompleted.JobsCompleted
import com.moub.PERDAY.ui.employee.recentlyJob.newJobs.JobsSubmitted

class tabAdapter(val context: Context, fm: FragmentManager): FragmentPagerAdapter(fm) {
    var itemsCount = 2
    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> JobsCompleted()
            else -> {
                return JobsSubmitted()
            }
        }
    }

    override fun getCount(): Int {
        return itemsCount
    }

    override fun getPageTitle(position: Int): CharSequence {
        return when (position) {
            0 -> "New Jobs"
            else -> {
                return "Jobs completed"
            }
        }
    }
}