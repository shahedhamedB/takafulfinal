package com.moub.PERDAY.ui.employer.welcome

import android.widget.TextView

interface WelcomeContractEmployer {
    fun navigateToHome()
    fun navigateToRegister()
    fun animationTxt(text: TextView)
}