package com.moub.PERDAY.ui.employer.questions

interface QuestionContract {
    fun showProgressBar()
    fun hideProgressBar()
}