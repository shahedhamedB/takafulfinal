package com.moub.PERDAY.ui.employer.auth.register

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.widget.Spinner
import java.io.IOException
import java.util.*

class RegisterPresenter(val contract: RegisterContract, val registerInteractor: RegisterInteractor) :
    RegisterInteractor.OnSignUpFinishedListener {
    override fun onSuccess(
        email: String,
        password: String,
        legalname: String,
        representativePerson: String,
        phone: String,
        long: String,
        lat: String,
        country:String,
        sectorSpinner: String,logo:String
    ) {
        registerInteractor.SignUpPresenter(email, password, legalname,representativePerson,phone,long,lat,country,sectorSpinner,logo, this)
    }

    interface listner {
        fun hideProgressPar()
    }

    fun getCountryName(
        context: Context,
        listner: listner,
        latitude: Double,
        longitude: Double,
        location: (String, String, String,Double,Double) -> Unit
    ) {
        val geocoder = Geocoder(context, Locale.getDefault())
        val addresses: List<Address>?
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1)
            val result: Address

            if (addresses != null && addresses.isNotEmpty()) {

                location(addresses[0].adminArea, addresses[0].subLocality, addresses[0].countryName,longitude,latitude)
                listner.hideProgressPar()
            } else null
        } catch (ignored: IOException) {
        }
    }

    override fun onPhoneError() {
        contract.apply {
            setPhoneError()
            hideProgress()
        }
    }

    override fun onRepresentativePersonError() {
        contract.apply {
            setPersonError()
            hideProgress()
        }
    }

    override fun onSectorError() {
        contract.apply {
            setSectorError()
            hideProgress()
        }
    }

    fun validateCredentials(email: String, password: String, name: String,phone:String,representativePerson :String, long: String,
                            lat: String,country:String,sector:String,logo:String) {
        contract.showProgress()
        registerInteractor.signUp(email, password, name,phone,representativePerson,long,lat,country,sector,logo, this)
    }

    override
    fun onNameError() {
        contract.apply {
            setPersonError()
            hideProgress()

        }
    }

    override fun onEmailError() {
        contract.apply {
            setEmailError()
            hideProgress()
        }
    }

    override fun onPasswordError() {
        contract.apply {
            setPasswordError()
            hideProgress()
        }
    }



    override fun onNavigate() {
        contract.navigateToHome()
    }


    override fun toast(toast: String) {
        contract.toast(toast)
    }

    override fun hideProgress() {
        contract.hideProgress()

    }

    fun spinner(spinner: Spinner, language: Array<String>) {
        contract.spinner(language, spinner)
    }
}