package com.moub.PERDAY.ui.userStatus

class UserStatusPresenter(val userView: UserStatusView, val userInteractor: UserStatusInteractor) :
    UserStatusInteractor.OnStatusFinishedListener {

    fun employee() {
        onEmployeeNavigate()
    }

    override fun onEmployeeNavigate() {
        userView.employeeNavigate()
    }

    override fun onEmployerNavigate() {
        userView.employerNavigate()
    }

    override fun toast(toast: String) {
        userView.toast(toast)
    }



}