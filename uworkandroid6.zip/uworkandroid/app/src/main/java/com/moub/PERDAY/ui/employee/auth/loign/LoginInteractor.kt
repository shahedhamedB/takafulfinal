package com.moub.PERDAY.ui.employee.auth.loign

import android.os.Handler
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.moub.PERDAY.managers.fireStoreManager

class LoginInteractor {
    interface OnLoginFinishedListener {
        fun onEmailError()
        fun onPasswordError()
        fun onSuccess(email: String, password: String)
        fun onNavigate()
        fun toast(toast: String)
        fun hideProgress()
    }

    fun logIn(email: String, password: String, listener: OnLoginFinishedListener) {
        Handler().postDelayed({
            when {
                email.isEmpty() -> listener.onEmailError()
                password.isEmpty() -> listener.onPasswordError()
                else ->
                    listener.onSuccess(email, password)
            }
        }, 1000)
    }

    fun performLogin(email: String, passowrd: String, listener: OnLoginFinishedListener) {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, passowrd)
            .addOnCompleteListener {
                if (!it.isSuccessful) return@addOnCompleteListener
                Log.d("Login", "Successfully logged in: ${it.result!!.user.uid}")
                fireStoreManager.checkUserEmployee { EmployeeData ->
                    val userEmail = EmployeeData.email
                    if (email == userEmail) {
                        val mAuth = FirebaseAuth.getInstance()
                        val user = mAuth.currentUser
                        if (user!!.isEmailVerified){
                            listener.onNavigate()
                        }else{
                            listener.toast("your email it's not verified !! \n Please check your email")
                            listener.hideProgress()

                        }
                    }else{
                        listener.toast("This e-mail address is not registered as an employee !!")
                        listener.hideProgress()

                    }
                }


            }
            .addOnFailureListener {
                listener.toast(it.toString())
                listener.hideProgress()
            }
    }

}