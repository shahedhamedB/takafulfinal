package com.moub.PERDAY.ui.employee.employeeWorkInfo

import android.widget.TextView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.BaseViewHolder
import com.moub.PERDAY.R


class WorkInfoAdapter(data: ArrayList<String>, val onCLick: (TextView, Int) -> Unit) :
    BaseQuickAdapter<String, BaseViewHolder>(R.layout.item_num_hours, data) {

    override fun convert(helper: BaseViewHolder, item: String) {
        helper.setText(R.id.txtNum, item)
        helper.getView<TextView>(R.id.txtNum).setOnClickListener {
            onCLick(helper.getView(R.id.txtNum),helper.adapterPosition)
        }
    }
}
