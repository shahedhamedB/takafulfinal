package com.moub.PERDAY.ui.employer.post.newPosts


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.moub.PERDAY.R
import com.moub.PERDAY.model.PostModel
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.fragment_new_posts.*

class NewPosts : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_new_posts, container, false)
        getComment {
            postsRecyclerView.adapter = NewPostsAdapter(it, activity!!) { onClick, size ->
                AppLogger.toast(activity!!, onClick)
            }
        }
        return view
    }

    fun getComment(onComplete: (MutableList<PostModel>) -> Unit): ListenerRegistration {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = FirebaseFirestore.getInstance().collection("allPostsJob").whereEqualTo("id",id)
        return doc.addSnapshotListener { querySnapshot, _ ->
            try {
                onComplete(querySnapshot!!.toObjects(PostModel::class.java))
            } catch (e: Exception) {
            }
        }
    }

}
