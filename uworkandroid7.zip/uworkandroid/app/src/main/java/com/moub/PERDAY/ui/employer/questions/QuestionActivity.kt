package com.moub.PERDAY.ui.employer.questions

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.fireStoreManager
import kotlinx.android.synthetic.main.activity_question.*
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

@Suppress("NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
class QuestionActivity : AppCompatActivity() , QuestionContract {
    private var EmployeeName: String = ""
    private var EmployeeId: String = ""
    private var Time: String = ""


    val presenter = QuestionPresenter()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_question)
        getBundleData()
        getTime()
        AskBtnEmployer.setOnClickListener {
            showProgressBar()
            presenter.AskEmployee(this, editText2.text.toString(),this.EmployeeId,this.Time,this.EmployeeName,progressBarQuestion)
            editText2.text.clear()
            fireStoreManager.notiStatus(this.EmployeeId)
            fireStoreManager.createNotificationsItem(this.EmployeeId,"question",this.Time)
            hideProgressBar()

        }
        fireStoreManager.getDataQuestions(this.EmployeeId){
            answerRecyclerView.adapter = QuestionAdapter(it,this){size ->
                numOfAnswers.text = size
            }}
    }



    @SuppressLint("SetTextI18n")
    fun getBundleData() {
        val bundle = intent.extras
        if (bundle != null) {
            this.EmployeeId = bundle.getString("EmployeeId")
            this.EmployeeName = bundle.getString("EmployeeName")
            titleTxt.text = "Ask the employee ${this.EmployeeName}"
        }
    }

    fun getTime() {
        val current = LocalDateTime.now()
        val formatter = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
        val formatted = current.format(formatter)
        this.Time = formatted
    }

    override fun showProgressBar() {
        progressBarQuestion.visibility = View.VISIBLE
    }

    override fun hideProgressBar() {
        progressBarQuestion.visibility = View.GONE
    }


    companion object {
        fun start(context: Context) {
            val intent = Intent(context, QuestionActivity::class.java)
            context.startActivity(intent)
        }
    }
}
