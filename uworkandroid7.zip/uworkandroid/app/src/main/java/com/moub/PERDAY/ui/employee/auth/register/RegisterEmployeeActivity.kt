package com.moub.PERDAY.ui.employee.auth.register

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import com.moub.PERDAY.R
import com.moub.PERDAY.TestActivity
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.ui.confirmEmail.ConfirmEmail
import com.moub.PERDAY.ui.employee.employeePersonalInfo.EmployeeDataActivity
import com.moub.PERDAY.utils.AppLogger
import com.moub.PERDAY.ui.employee.auth.loign.LoginActivity
import com.moub.PERDAY.ui.phoneVerfiy.RegisterActivity
import kotlinx.android.synthetic.main.activity_register.*

class RegisterEmployeeActivity : AppCompatActivity(), RegisterContract {


    private val presenter = RegisterPresenter(this, RegisterInteractor())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        signUpBtn.setOnClickListener { validateCredentials() }
        loginBtn.setOnClickListener { navigateToLogin() }
        testBtn.setOnClickListener { EmployeeDataActivity.start(this) }
        registerViaPhoneNavigation()
        signUpBtnTest.setOnClickListener { TestActivity.start(this) }
    }

    fun registerViaPhoneNavigation() {
        phone.setOnClickListener {
            RegisterActivity.start(this)
            finish()
        }
    }

    private fun validateCredentials() {
        presenter.validateCredentials(
            email.text.toString().trim(),
            password.text.toString().trim(),
            name.text.toString().trim()
        )
        CacheManager.instance.setUserName(name.text.toString().trim())
    }

    override fun showProgress() {
        progressBar.visibility = View.VISIBLE

    }

    override fun hideProgress() {
        progressBar.visibility = View.GONE

    }

    override fun setEmailError() {
        email.error = getString(R.string.username_error)

    }

    override fun setPasswordError() {
        password.error = getString(R.string.password_error)

    }

    override fun setNameError() {
        name.error = getString(R.string.name_error)
    }

    override fun navigateToHome() {
        val intent = Intent(this, ConfirmEmail::class.java)
        intent.putExtra("EmployeeEmail", email.text.toString())
        this.startActivity(intent)
        finish()
        AppLogger.toast(this, getString(R.string.navigate_home))
    }

    override fun navigateToLogin() {
        LoginActivity.start(this)
        AppLogger.toast(this, getString(R.string.navigate_home))
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, RegisterEmployeeActivity::class.java)
            context.startActivity(intent)}
    }
    override fun toast(message: String) {
        AppLogger.toast(this, message)
    }


}
