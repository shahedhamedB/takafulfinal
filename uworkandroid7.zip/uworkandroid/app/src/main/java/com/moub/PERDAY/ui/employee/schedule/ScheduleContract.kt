package com.moub.PERDAY.ui.employee.schedule

interface ScheduleContract {
}