package com.moub.PERDAY.ui.employee.auth.loign

import com.moub.PERDAY.managers.CacheManager

class LoginPresenter(var loginContract: LoginContract, val loginInteractor: LoginInteractor) :
    LoginInteractor.OnLoginFinishedListener {


    fun validateCredentials(email: String, password: String) {
        loginContract.showProgress()
        loginInteractor.logIn(email, password, this)
    }

    override fun onEmailError() {
        loginContract.apply {
            setEmailError()
            hideProgress()
        }
    }

    override fun onPasswordError() {
        loginContract.apply {
            setPasswordError()
            hideProgress()
        }
    }

    override fun onSuccess(email: String, password: String) {
        loginInteractor.performLogin(email, password, this)
        CacheManager.instance.setCheckEmployee("Employee")

    }

    override fun onNavigate() {
        loginContract.navigateToHome()
    }

    override fun toast(toast: String) {
        loginContract.toast(toast)
    }

    override fun hideProgress() {
        loginContract.hideProgress()
    }
}