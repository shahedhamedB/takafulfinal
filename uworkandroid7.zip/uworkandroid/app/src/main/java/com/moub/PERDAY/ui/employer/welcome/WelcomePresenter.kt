package com.moub.PERDAY.ui.employer.welcome

import android.view.animation.AccelerateInterpolator
import android.view.animation.AlphaAnimation
import android.view.animation.AnimationSet
import android.view.animation.DecelerateInterpolator
import android.widget.TextView

class WelcomePresenterEmployer(val contract: WelcomeContractEmployer, val interactor: WelcomeInteractorEmployer) :
    WelcomeInteractorEmployer.OnWelcomeFinishedListener {

    fun userverification() {
        interactor.verification(this)
    }

    override fun onSuccess() {
    }

    override fun onNavigateHome() {
        contract.navigateToHome()
    }

    override fun onNavigateRegister() {
        contract.navigateToRegister()
    }

    fun animation(text: TextView) {
        val fadeIn = AlphaAnimation(0f, 1f)
        fadeIn.interpolator = DecelerateInterpolator() //add this
        fadeIn.duration = 1000

        val fadeOut = AlphaAnimation(1f, 0f)
        fadeOut.interpolator = AccelerateInterpolator() //and this
        fadeOut.startOffset = 1000
        fadeOut.duration = 1000

        val animation = AnimationSet(false) //change to false
        animation.addAnimation(fadeIn)
        animation.addAnimation(fadeOut)
        text.animation = animation
    }
}