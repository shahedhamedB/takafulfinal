package com.moub.PERDAY.ui.employee.home

import android.widget.Spinner

class HomePresenter(val contract: HomeContract) {
    fun spinner(spinner: Spinner, language:Array<String> ) {
        contract.spinner(language, spinner)
    }




}