package com.moub.PERDAY.ui.employer.main


import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.events.calendar.utils.EventsCalendarUtil
import com.events.calendar.views.EventsCalendar

import com.moub.PERDAY.R
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.fragment_schedual_employer.*
import kotlinx.android.synthetic.main.fragment_schedual_employer.view.*
import kotlinx.android.synthetic.main.fragment_schedule.eventsCalendar
import kotlinx.android.synthetic.main.fragment_schedule.selected
import kotlinx.android.synthetic.main.fragment_schedule.view.eventsCalendar
import kotlinx.android.synthetic.main.fragment_schedule.view.selected
import java.util.*

class SchedualEmployer : Fragment(), EventsCalendar.Callback {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_schedual_employer, container, false)
    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val today = Calendar.getInstance()
        val end = Calendar.getInstance()
        end.add(Calendar.YEAR, 2)
        view!!.eventsCalendar.setSelectionMode(eventsCalendar.MULTIPLE_SELECTION)
        view!!.eventsCalendar.setToday(today)
        view!!.eventsCalendar.setMonthRange(today, end)
        view!!.eventsCalendar.setWeekStartDay(Calendar.SUNDAY, false)
        view!!.eventsCalendar.setCurrentSelectedDate(today)
        view!!.eventsCalendar.setCallback(this)

        addEvents()
        view!!.selected.text = getDateString(eventsCalendar.getCurrentSelectedDate()?.timeInMillis)
        selected.setOnClickListener {
            val dates = eventsCalendar.getDatesFromSelectedRange()
            Log.e("SELECTED SIZE", dates.size.toString())
            activity?.let { it1 -> AppLogger.toast(it1, "hi hi hi ") }
//             eventsCalendar.setCurrentSelectedDate(eventsCalendar.getCurrentSelectedDate())
        }


        val dc = Calendar.getInstance()
        dc.add(Calendar.DAY_OF_MONTH, 2)
//        eventsCalendar.disableDate(dc)
//        eventsCalendar.disableDaysInWeek(Calendar.SATURDAY, Calendar.SUNDAY)
    }

    override fun onDayLongPressed(selectedDate: Calendar?) {
        Log.e("LONG CLICKED", EventsCalendarUtil.getDateString(selectedDate, EventsCalendarUtil.DD_MM_YYYY))
    }

    override fun onMonthChanged(monthStartDate: Calendar?) {
        Log.e("MON", "CHANGED")
    }

    override fun onDaySelected(selectedDate: Calendar?) {
        Log.e("CLICKED", EventsCalendarUtil.getDateString(selectedDate, EventsCalendarUtil.DD_MM_YYYY))
        view?.selected!!.text = getDateString(selectedDate?.timeInMillis)
        view!!.viewEvent.text = getDateString(selectedDate?.timeInMillis)
        val date = viewEvent.text.toString()
        Toast.makeText(activity, date, Toast.LENGTH_SHORT).show()

    }

    fun addEvents() {
        val c = Calendar.getInstance()
        val a: Int = 0
        c.add(Calendar.DAY_OF_MONTH, a)
        eventsCalendar.addEvent(c)
        c.add(Calendar.DAY_OF_MONTH, 3)
        eventsCalendar.addEvent(c)
        c.add(Calendar.DAY_OF_MONTH, 4)
        eventsCalendar.addEvent(c)
        c.add(Calendar.DAY_OF_MONTH, 7)
        eventsCalendar.addEvent(c)
        c.add(Calendar.DAY_OF_MONTH, 2)
        eventsCalendar.addEvent(c)
        c.add(Calendar.DAY_OF_MONTH, 1)
        eventsCalendar.addEvent(c)
    }

    fun getDateString(time: Long?): String {
        if (time != null) {
            val cal = Calendar.getInstance()
            cal.timeInMillis = time
            val month = when (cal[Calendar.MONTH]) {
                Calendar.JANUARY -> "January"
                Calendar.FEBRUARY -> "February"
                Calendar.MARCH -> "March"
                Calendar.APRIL -> "April"
                Calendar.MAY -> "May"
                Calendar.JUNE -> "June"
                Calendar.JULY -> "July"
                Calendar.AUGUST -> "August"
                Calendar.SEPTEMBER -> "September"
                Calendar.OCTOBER -> "October"
                Calendar.NOVEMBER -> "November"
                Calendar.DECEMBER -> "December"
                else -> ""
            }
            return "$month ${cal[Calendar.DAY_OF_MONTH]}, ${cal[Calendar.YEAR]}"
        } else return ""
    }

}
