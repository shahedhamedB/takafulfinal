package com.moub.PERDAY.ui.employer.applicants


import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.moub.PERDAY.R
import com.moub.PERDAY.ui.base.BaseActivity
import kotlinx.android.synthetic.main.activity_recently2.tabLayout
import kotlinx.android.synthetic.main.fragment_blank_fragment2.*

@SuppressLint("Registered")
class Applicants : BaseActivity() {
    private var employerId: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_blank_fragment2)
        tab()

    }



    fun tab(){
        val fragmentAdapter = ApplicantsAdapter(this, supportFragmentManager)
        viewPagerApplicants.adapter = fragmentAdapter
        tabLayout.setupWithViewPager(viewPagerApplicants)
        viewPagerApplicants.offscreenPageLimit = 2
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, Applicants::class.java)
            context.startActivity(intent)
        }
    }
}
