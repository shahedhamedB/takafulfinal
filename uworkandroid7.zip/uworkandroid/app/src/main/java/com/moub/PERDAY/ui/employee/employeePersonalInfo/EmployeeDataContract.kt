package com.moub.PERDAY.ui.employee.employeePersonalInfo

import android.widget.Spinner

interface EmployeeDataContract {
    fun setLanguageSpinner(onClick: (String) -> Unit)
    fun setMaterialStatusSpinner()
    fun setHelthConditionsSpinner()
    fun setfamilySizeSpinner()
    fun setfamilyJobSpinner()
    fun setYearSpinner()
    fun setMonthSpinner()
    fun setDaySpinner()
    fun spinner(languages:Array<String>,spinner: Spinner,onClick:(String)->Unit)
}