package com.moub.PERDAY.ui.employee.auth.register

interface RegisterContract {
    fun showProgress()
    fun hideProgress()
    fun setEmailError()
    fun setPasswordError()
    fun setNameError()
    fun navigateToHome()
    fun navigateToLogin()
    fun toast(message:String)


}