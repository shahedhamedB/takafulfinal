package com.moub.PERDAY.ui.employee.auth.register

import android.os.Handler
import com.google.firebase.auth.FirebaseAuth
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.utils.AppLogger

class RegisterInteractor {
    interface OnSignUpFinishedListener {
        fun onEmailError()
        fun onPasswordError()
        fun onNameError()
        fun onSuccess(email: String, password: String, name: String)
        fun onNavigate()
        fun toast(toast: String)
        fun hideProgress()
    }

    fun signUp(email: String, password: String, name: String, listener: OnSignUpFinishedListener) {
        Handler().postDelayed({
            when {
                email.isEmpty() -> listener.onEmailError()
                password.isEmpty() -> listener.onPasswordError()
                name.isEmpty() -> listener.onNameError()
                else ->
                    listener.onSuccess(email, password, name)
            }
        }, 1000)
    }

    fun signUpPresenter(email: String, passowrd: String, name: String, listener: OnSignUpFinishedListener) {
        val auth = FirebaseAuth.getInstance()
        auth.createUserWithEmailAndPassword(email, passowrd)
            .addOnCompleteListener {
                if (!it.isSuccessful) return@addOnCompleteListener
                listener.onNavigate()
                AppLogger.log("", "Successfully created user with uid: ${it.result!!.user.uid}")
                fireStoreManager.saveEmployeeData(email, name)

            }
            .addOnFailureListener {
                AppLogger.log("", "Failed to create user: ${it.message}")
                listener.hideProgress()
                listener.toast(it.toString())
            }
    }


}