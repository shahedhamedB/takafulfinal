package com.moub.PERDAY.ui.employee.auth.loign

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import com.google.firebase.auth.FirebaseAuth
import com.moub.PERDAY.R
import com.moub.PERDAY.ui.forgetPassword.ForgetPassword
import com.moub.PERDAY.ui.employee.main.MainActivity
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity(), LoginContract {
    private val presenter = LoginPresenter(this, LoginInteractor())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        LoginBtn.setOnClickListener { validateCredentials() }
        restPassword.setOnClickListener { navigateRestPassword() }
    }

    public override fun onStart() {
        super.onStart()
        FirebaseAuth.getInstance()
    }

    private fun validateCredentials() {
        presenter.validateCredentials(email.text.toString().trim(), password.text.toString().trim())
    }

    override fun showProgress() {
        progressBar.visibility = View.VISIBLE
    }

    override fun hideProgress() {
        progressBar.visibility = View.GONE
    }

    override fun setEmailError() {
        email.error = "Email cannot be empty"
    }

    override fun setPasswordError() {
        password.error = getString(R.string.password_error)
    }

    override fun navigateToHome() {
        MainActivity.start(this)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)

    }

    override fun toast(message: String) {
        AppLogger.toast(this, message)
    }

    override fun navigateRestPassword() {
        ForgetPassword.start(this)
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, LoginActivity::class.java)
            context.startActivity(intent)
        }
    }
}
