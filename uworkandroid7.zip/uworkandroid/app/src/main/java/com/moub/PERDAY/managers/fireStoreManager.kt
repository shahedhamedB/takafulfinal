package com.moub.PERDAY.managers

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Context
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import com.moub.PERDAY.R
import com.moub.PERDAY.model.*
import com.moub.PERDAY.model.employeeModel.EmployeeData
import com.moub.PERDAY.ui.employee.employeeWorkInfo.EmployeeWorkinfoActivity
import com.moub.PERDAY.ui.userStatus.UserStatus
import com.moub.PERDAY.utils.AppConstants
import com.moub.PERDAY.utils.AppLogger

object fireStoreManager {
    @SuppressLint("StaticFieldLeak")
    val db = FirebaseFirestore.getInstance()

    fun deleteJobs(RequestId: String) {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        FirebaseFirestore.getInstance().collection("employerUsers")
            .document(id)
            .collection("Jobs").document(RequestId)
            .delete()
            .addOnSuccessListener { Log.d("", "DocumentSnapshot successfully deleted!") }
            .addOnFailureListener { e -> Log.w("", "Error deleting document", e) }
    }

    fun getNotificationsListenerforEmployee(notiMain: ImageView) {

        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val docRef = FirebaseFirestore.getInstance()
            .collection("employee")
            .document(id)
        docRef.addSnapshotListener(EventListener<DocumentSnapshot> { snapshot, e ->
            if (e != null) {
                Log.w(TAG, "Listen failed.", e)
                return@EventListener
            }
            if (snapshot != null && snapshot.exists()) {
                val noti: String = snapshot.data!!["notification"].toString()
                if (noti == "1") {
                    notiMain.setBackgroundResource(R.drawable.ic_notification_hold)
                } else if (noti == "0") {
                    notiMain.setBackgroundResource(R.drawable.noti_btn)
                }
                Log.d(TAG, "Current data: ${snapshot.data}")
            } else {
                Log.d(TAG, "Current data: null")
            }
        })
    }


    fun getNotificationsListenerforEmployer(notiMain: ImageView) {

        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val docRef = FirebaseFirestore.getInstance()
            .collection("employee")
            .document(id)
        docRef.addSnapshotListener(EventListener<DocumentSnapshot> { snapshot, e ->
            if (e != null) {
                Log.w(TAG, "Listen failed.", e)
                return@EventListener
            }
            if (snapshot != null && snapshot.exists()) {
                val noti: String = snapshot.data!!["notification"].toString()
                if (noti == "1") {
                    notiMain.setBackgroundResource(R.drawable.ic_notification_hold)
                } else if (noti == "0") {
                    notiMain.setBackgroundResource(R.drawable.noti_btn)
                }
                Log.d(TAG, "Current data: ${snapshot.data}")
            } else {
                Log.d(TAG, "Current data: null")
            }
        })
    }


    fun changeNotiStatus() {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val db = FirebaseFirestore.getInstance()
        db.collection("employee")
            .document(id).update("notification", "0")
    }


    fun notiStatus(EmployeeId: String) {
        val db = FirebaseFirestore.getInstance()
        db.collection("employee").document(EmployeeId).update("notification", "1")
    }

    fun saveEmployeeData(email: String, name: String) {

        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val employeeData = EmployeeData(id = id, email = email, userName = name, notification = "0")

        db.collection("employee").document(id)
            .set(employeeData)
            .addOnSuccessListener { AppLogger.log(TAG, "DocumentSnapshot successfully written!") }
            .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }
    }

    fun getDataQuestions(EmployeeId: String, onComplete: (MutableList<QuestionModel>) -> Unit): ListenerRegistration {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = FirebaseFirestore.getInstance()
            .collection("employerUsers").document(id).collection("Question").whereEqualTo("employeeID", EmployeeId)
            .whereEqualTo("answerStatus", "answer")
        return doc.addSnapshotListener { querySnapshot, firebaseExeption ->
            Log.w("firebaseExeption", "" + firebaseExeption)
            Log.i("firebaseExeption", "" + querySnapshot)

            onComplete(querySnapshot!!.toObjects(QuestionModel::class.java))
        }
    }

    fun getDataQuestionsEmployee(onComplete: (MutableList<QuestionModel>) -> Unit): ListenerRegistration {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = FirebaseFirestore.getInstance()
            .collection("employee").document(id).collection("Question")
        return doc.addSnapshotListener { querySnapshot, firebaseExeption ->
            Log.w("firebaseExeption", "" + firebaseExeption)
            Log.i("firebaseExeption", "" + querySnapshot)
            onComplete(querySnapshot!!.toObjects(QuestionModel::class.java))
        }
    }

    private var requestIdCreateQuestion: String = ""
    private var requestIdCreateQuestionEmployer: String = ""
    fun creatQuestion(
        EmployeeId: String,
        question: String,
        answer: String,
        Time: String,
        EmployeeName: String,
        ProgressBar: ProgressBar
    ) {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = db.collection("employee").document(EmployeeId).collection("Question").document()
        val docEmployer = db.collection("employerUsers").document(id).collection("Question").document()
        requestIdCreateQuestionEmployer = docEmployer.id

        requestIdCreateQuestion = doc.id
        val questionData = QuestionModelEmployee(
            id,
            EmployeeId,
            question,
            answer,
            requestIdCreateQuestion,
            Time,
            EmployeeName,
            "noAnswer",
            this.requestIdCreateQuestionEmployer
        )
        val questionDataforEmployer =
            QuestionModel(
                id,
                EmployeeId,
                question,
                answer,
                this.requestIdCreateQuestionEmployer,
                Time,
                EmployeeName,
                "noAnswer"
            )
        doc.set(questionData).addOnSuccessListener {
            AppLogger.log(TAG, "DocumentSnapshot successfully written!")
            ProgressBar.visibility = View.GONE
        }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error writing document", e)
                ProgressBar.visibility = View.GONE
            }
        docEmployer.set(questionDataforEmployer)
            .addOnSuccessListener { AppLogger.log(TAG, "DocumentSnapshot successfully written!") }
            .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }
    }

    fun createNotificationsItem(EmployeeId: String, notificationsType: String, time: String) {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = db.collection("employee").document(EmployeeId).collection("Notifications").document()
        val requestId = doc.id
        val notiItems =
            NotificationsItemsModel(id, EmployeeId, notificationsType, requestIdCreateQuestion, time, requestId)
        doc.set(notiItems)
    }


    fun ApplayJobEmployee(
        employerId: String, legalName: String, jobTilte: String, location: String,
        educationalLevel: String,
        week: String,
        day: String,
        jobCategory: String,
        description: String,
        logo: String,
        time: String
    ) {

        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val employeeData = ApplayModel(
            employerId,
            id,
            legalName,
            jobTilte,
            location,
            educationalLevel,
            week,
            day,
            jobCategory,
            description,
            logo,
            time
        )

        db.collection("AppliedJob").document(id).collection("ApplayPost").document()
            .set(employeeData)
            .addOnSuccessListener { AppLogger.log(TAG, "DocumentSnapshot successfully written!") }
            .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }
    }

    fun createPostOnFirestore(
        context: Context,
        legalName: String,
        jobTilte: String, numWorkers: String, location: String,
        educationalLevel: String,
        week: String,
        day: String,
        experance: String,
        jobCategory: String,
        description: String,
        payment: String,
        logo: String

    ) {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = db.collection("employerUsers").document(id).collection("posts").document()
        val requestId = doc.id
        val postData = PostModel(
            requestId,
            id,
            legalName,
            jobTilte,
            numWorkers,
            location,
            educationalLevel,
            week,
            day,
            experance,
            jobCategory,
            description,
            payment,
            logo
        )

        db.collection("allPostsJob").document()
            .set(postData)
            .addOnSuccessListener {
                AppLogger.log(TAG, "DocumentSnapshot successfully written!")
                AppLogger.toast(context, "Post has been successfully created")
            }
            .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }

        db.collection("PostJob").document(jobCategory).collection("posts").document().set(postData)
        doc.set(postData)
    }

    fun saveEmployerData(
        email: String, legalName: String, representativePerson: String,
        phone: String,
        long: String,
        lat: String,
        country: String,
        sectorSpinner: String, logo: String
    ) {

        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val employeeData =
            EmployerData(
                id,
                email,
                legalName,
                representativePerson,
                phone,
                long,
                lat,
                country,
                sectorSpinner,
                logo,
                "0"
            )

        db.collection("employerUsers").document(id)
            .set(employeeData)
            .addOnSuccessListener { AppLogger.log(TAG, "DocumentSnapshot successfully written!") }
            .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }
    }

    fun saveEmployeePersonalInfo(
        context: Context, languagesEmployee: String, material: String, helth: String,
        familySize: String,
        familyWork: String,
        year: String,
        month: String,
        day: String,
        location: String
    ) {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val employeeData = EmployeePersonalInfo(
            id,
            languagesEmployee,
            material,
            helth,
            familySize,
            familyWork,
            year,
            month,
            day,
            location
        )

        db.collection("EmployeePersonalInfo").document(id)
            .set(employeeData)
            .addOnSuccessListener {
                AppLogger.log(TAG, "DocumentSnapshot successfully written!")
                EmployeeWorkinfoActivity.start(context)

            }
            .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }
    }

    fun saveApplaiedJobEmployee(
        idEmployer: String, employeeName: String, experiance: String, location: String,
        educationalLevel: String,
        week: ArrayList<String>,
        day: ArrayList<Int>,
        jobCategory: ArrayList<String>,
        time: String, legalName: String, jobTilte: String, locationEmployer: String, jobCategoryEmployer: String
    ) {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val dr: DocumentReference = db.collection("employerUsers").document(idEmployer)
            .collection("employee").document()

        val doc: DocumentReference = db.collection("employee").document(id)
            .collection("Applicants").document()
        val requestId = dr.id


        val docRef = db.collection("employerUsers").document(idEmployer)
            .collection("Jobs").document(requestId)

        val docRequestId = docRef.id

        val employeeData = saveApplaiedEmployeeModel(
            idEmployer,
            id,
            "pending",
            employeeName,
            experiance,
            location,
            educationalLevel,
            week,
            day,
            jobCategory,
            time, requestId, legalName, jobTilte, locationEmployer, jobCategoryEmployer
        )

        val setJobsEmployer = setJobsEmployerModel(
            idEmployer,
            id,
            "",
            employeeName,
            experiance,
            location,
            educationalLevel,
            week,
            day,
            jobCategory,
            time, docRequestId, requestId, legalName, jobTilte, locationEmployer, jobCategoryEmployer
        )


        dr.set(employeeData)
            .addOnSuccessListener {
                AppLogger.log(TAG, "DocumentSnapshot successfully written!")
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error writing document", e)
            }


        doc.set(employeeData)
            .addOnSuccessListener {
                AppLogger.log(TAG, "DocumentSnapshot successfully written!")
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error writing document", e)
            }
        docRef.set(setJobsEmployer)

    }


    fun acceptApplicants(requestId: String) {
        val EmployerId = FirebaseAuth.getInstance().currentUser!!.uid
        db.collection("employerUsers").document(EmployerId)
            .collection("employee").document(requestId)
            .update(
                "status", AppConstants.Status.ACCEPTED
            )
    }

    fun acceptApplicantsForEmployee(
        EmployeeId: String,
        legalName: String,
        jobTilte: String,
        numWorkers: String,
        location: String,
        educationalLevel: String,
        week: String,
        day: String,
        experance: String,
        jobCategory: String,
        description: String,
        payment: String,
        logo: String
    ) {
        val EmployerId = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = db.collection("employee").document(EmployeeId).collection("Jobs").document()
        val requesUid = doc.id
        val postData = PostModel(
            requesUid,
            EmployerId,
            legalName,
            jobTilte,
            numWorkers,
            location,
            educationalLevel,
            week,
            day,
            experance,
            jobCategory,
            description,
            payment,
            logo
        )
        doc.set(postData)
            .addOnSuccessListener {
                AppLogger.log(TAG, "DocumentSnapshot successfully written!")
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error writing document", e)
            }

    }

    fun saveEmployeeWorkInfo(
        educational: String, recentJobTitle: String, yearOfExperiance: String,
        fieldOfExperiance: ArrayList<String>,
        weekDaysAvalability: ArrayList<String>,
        dayHours: ArrayList<Int>
    ) {

        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val employeeData = EmployeeWorkInfo(
            id,
            educational,
            recentJobTitle,
            yearOfExperiance,
            fieldOfExperiance,
            weekDaysAvalability,
            dayHours
        )

        db.collection("EmployeeWorkInfo").document(id)
            .set(employeeData)
            .addOnSuccessListener { AppLogger.log(TAG, "DocumentSnapshot successfully written!") }
            .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }
    }

    fun checkUserEmployee(onCmplete: (EmployeeData) -> Unit) {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val docRef = db.collection("employee").document(id)
        docRef.get().addOnSuccessListener { document ->
            if (document != null) {
                onCmplete(document.toObject(EmployeeData::class.java)!!)
                AppLogger.log(TAG, "DocumentSnapshot data: ${document.data}")
            } else {
                AppLogger.log(TAG, "No such document")
            }
        }
            .addOnFailureListener { exception ->
                Log.d(TAG, "get failed with ", exception)
            }
    }

    fun checkUserEmployer(onCmplete: (EmployerData) -> Unit) {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val docRef = db.collection("employerUsers").document(id)
        docRef.get().addOnSuccessListener { document ->
            if (document != null) {
                onCmplete(document.toObject(EmployerData::class.java)!!)
                AppLogger.log(TAG, "DocumentSnapshot data: ${document.data}")
            } else {
                AppLogger.log(TAG, "No such document")
            }
        }
            .addOnFailureListener { exception ->
                Log.d(TAG, "get failed with ", exception)
            }
    }

    fun getUID(): String {
        return FirebaseAuth.getInstance().currentUser!!.uid
    }

    fun ChckSplashEmployer(context: Context, onCmplete: (EmployerData) -> Unit) {
        val docRef = db.collection("employerUsers").document(getUID())
        docRef.get().addOnSuccessListener { document ->
            if (document == null) {
                AppLogger.log(TAG, "No such document")
                UserStatus.start(context)
            } else {
                onCmplete(document.toObject(EmployerData::class.java)!!)
                AppLogger.log(TAG, "DocumentSnapshot data: ${document.data}")
            }
        }
            .addOnFailureListener { exception ->
                Log.d(TAG, "get failed with ", exception)
                UserStatus.start(context)
            }
    }

    fun ChckSplashEmployee(context: Context, onCmplete: (EmployeeData) -> Unit) {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val docRef = db.collection("employerUsers").document(id)
        docRef.get().addOnSuccessListener { document ->
            if (document != null) {
                onCmplete(document.toObject(EmployeeData::class.java)!!)
                AppLogger.log(TAG, "DocumentSnapshot data: ${document.data}")
            } else {
                AppLogger.log(TAG, "No such document")
            }
        }
            .addOnFailureListener { exception ->
                Log.d(TAG, "get failed with ", exception)
                UserStatus.start(context)
            }
    }


}