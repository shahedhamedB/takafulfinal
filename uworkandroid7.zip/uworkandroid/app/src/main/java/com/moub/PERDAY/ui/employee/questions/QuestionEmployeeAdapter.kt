package com.moub.PERDAY.ui.employee.questions

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.moub.PERDAY.R
import com.moub.PERDAY.model.QuestionModel
import kotlinx.android.synthetic.main.item_answers_employer.view.*

class QuestionEmployeeAdapter (
    private val items: MutableList<QuestionModel>, val context: Context, val onClick: (String,String,String) -> Unit
) : RecyclerView.Adapter<QuestionEmployeeAdapter.viewHolder>() {
    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        val model = items[position]
        holder.EmployeeName.text = model.employeeName
        holder.QuestionTxt.text = model.question
        holder.Answer.text = model.answer
        holder.Time.text = model.time


        onClick(items.size.toString(),model.employerId, model.employeeID)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): viewHolder {
        return viewHolder(LayoutInflater.from(context).inflate(R.layout.item_answers_employer, p0, false))
    }

    override fun getItemCount(): Int {
        return items.size

    }


    class viewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val QuestionTxt = view.QuestionTxt
        val EmployeeName = view.EmployeeName
        val Answer = view.Answer
        val Time = view.Time

    }
}