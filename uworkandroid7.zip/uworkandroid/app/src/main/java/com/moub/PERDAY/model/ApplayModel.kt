package com.moub.PERDAY.model

class ApplayModel(
    val idEmployer:String,val id: String, val legalName:String,val jobTilte: String, val location: String,
    val educationalLevel: String,
    val week: String,
    val day: String,
    val jobCategory: String,
    val description:String,
    val logo :String,
    val time:String
) {
    constructor() : this("","", "", "", "", "", "",  "","","","","")
}