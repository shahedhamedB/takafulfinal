package com.moub.PERDAY.ui.confirmEmail

import com.google.firebase.auth.FirebaseAuth


class ConfirmEmailPresenter(val contract: ConfirmEmailContract) {
    fun signOut() {
        FirebaseAuth.getInstance().signOut()
        contract.toast("Logging out ...")
    }

    fun verfiy(Email: String ) {

        val mAuth = FirebaseAuth.getInstance()
        val user = mAuth.currentUser
        user!!.sendEmailVerification().addOnCompleteListener{ task ->
            if(task.isSuccessful){
                contract.hideProgress()
                contract.toast("successful")
                contract.navigateToData()
            }else{
                contract.toast("failed")
            }

            }
    }

}