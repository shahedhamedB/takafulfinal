package com.moub.PERDAY.ui.employer.auth.register

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import com.google.firebase.storage.FirebaseStorage
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.ui.base.BaseActivity
import com.moub.PERDAY.ui.employer.auth.login.LoginEmployerActivity
import com.moub.PERDAY.ui.employer.main.MainActivityEmployer
import com.moub.PERDAY.ui.employer.welcome.WelcomeActivityEmployer
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_register.*
import kotlinx.android.synthetic.main.activity_register.email
import kotlinx.android.synthetic.main.activity_register.password
import kotlinx.android.synthetic.main.activity_register.progressBar
import kotlinx.android.synthetic.main.activity_register.signUpBtn
import kotlinx.android.synthetic.main.activity_register2.*
import java.util.*

class RegisterEmployerActivity : BaseActivity(), RegisterContract, RegisterPresenter.listner {


    private val presenter = RegisterPresenter(this, RegisterInteractor())
    private var btn: Button? = null
    private var imageview: ImageView? = null
    private val CAMERA = 2
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register2)
        textView73.setOnClickListener { MainActivityEmployer.start(this) }
        signUpBtn.setOnClickListener { validateCredentials() }
        setSectorSpinner()
        getCurrentLocationBtn.setOnClickListener {
            progressBar.visibility = View.VISIBLE
            getCurrentLocation()
        }

        linearLayout2.setOnClickListener {
            progressBar.visibility = View.VISIBLE
            getCurrentLocation()
        }

        btn = findViewById<View>(R.id.btn) as Button
        imageview = findViewById<View>(R.id.iv) as ImageView

        btn!!.setOnClickListener { showPictureDialog() }

    }

    private fun showPictureDialog() {
        val pictureDialog = AlertDialog.Builder(this)
        pictureDialog.setTitle("Select Action")
        val pictureDialogItems = arrayOf("Select photo from gallery", "Capture photo from camera")
        pictureDialog.setItems(
            pictureDialogItems
        ) { dialog, which ->
            when (which) {
                0 -> choosePhotoFromGallary()
                1 -> takePhotoFromCamera()
            }
        }
        pictureDialog.show()
    }

    fun choosePhotoFromGallary() {

        Log.d("", "Try to show photo selector")
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, 0)
        Toast.makeText(this, " please upload photo   ", Toast.LENGTH_SHORT)
            .show()
    }

    private fun takePhotoFromCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        val galleryIntent = Intent(
            Intent.ACTION_PICK,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        )
        try {
            startActivityForResult(galleryIntent, CAMERA)
            AppLogger.toast(this, "This feature will be activated soon")
        } catch (e: Exception) {
        }
    }

    private var selectedPhotoUri: Uri? = null
    private var logo: String = ""
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 0 && resultCode == Activity.RESULT_OK && data != null) {
            Log.d("", "Photo was selected")

            selectedPhotoUri = data.data

            val bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, selectedPhotoUri)
            iv.setImageBitmap(bitmap)
            uploadImageToFirebase {
            }

            Toast.makeText(this, " upload success ", Toast.LENGTH_SHORT).show()
        }
    }

    var Image1Ready: Boolean = false
    private var image:String = ""
    private fun uploadImageToFirebase(complete: () -> Unit) {
        if (selectedPhotoUri == null) return

        val filename = UUID.randomUUID().toString()
        val ref = FirebaseStorage.getInstance().getReference("/images/$filename")

        ref.putFile(selectedPhotoUri!!)
            .addOnSuccessListener {
                Log.d("", "Successfully uploaded image: ${it.metadata?.path}")
                ref.downloadUrl.addOnSuccessListener {
                    Log.d("", "File Location: $it")
                    Image1Ready = true
                    this.image = it.toString()
                    CacheManager.instance.setLogo(it.toString())
                    this.logo = it.toString()
                    complete()
                }
            }
            .addOnFailureListener {
                Log.d("", "Failed to upload image to storage: ${it.message}")
                AppLogger.toast(this,it.message.toString())

            }

    }

    override fun hideProgressPar() {
        progressBar.visibility = View.GONE
    }

    override fun setPhoneError() {
        phoneCompany.error = "Valid number is required"
        phoneCompany.requestFocus()
        hideProgressPar()

    }

    override fun setSectorError() {
        AppLogger.toast(this, "Please Chose Sector")
        hideProgressPar()

    }

    override fun setPersonError() {
        representativePerson.error = "Representative Person cannot be empty"
        hideProgressPar()

    }

    @SuppressLint("SetTextI18n")
    fun getCurrentLocation() {

        getLocation { longValue, latValue ->
            presenter.getCountryName(this, this, latValue, longValue) { location, subLocality, countryName, long, lat ->
                val country = location
                val SubLocality = subLocality
                val CountryName = countryName
                txtLong.text = "$CountryName , $country , $SubLocality"
                CacheManager.instance.setLongEmployer(long.toString())
                CacheManager.instance.setLatEmployer(lat.toString())
                CacheManager.instance.setcountry(country)
            }
        }
    }

    private fun validateCredentials() {
        val sector = CacheManager.instance.getSector()
        val long = CacheManager.instance.getLongEmployer()
        val lat = CacheManager.instance.getLatEmployer()
        val country = CacheManager.instance.getcountry()
        val logo = this.image
        presenter.validateCredentials(
            email.text.toString().trim(),
            password.text.toString().trim(),
            legalName.text.toString().trim(),
            phoneCompany.text.toString().trim(),
            representativePerson.text.toString().trim(),
            long, lat, country,
            sector, logo
        )
        CacheManager.instance.setlegalName(legalName.text.toString().trim())
    }

    override fun showProgress() {
        progressBar.visibility = View.VISIBLE

    }

    override fun hideProgress() {
        progressBar.visibility = View.GONE

    }

    override fun setEmailError() {
        email.error = getString(R.string.username_error)

    }

    override fun setPasswordError() {
        password.error = getString(R.string.password_error)

    }

    override fun setNameError() {
        name.error = getString(R.string.name_error)
    }

    override fun navigateToHome() {
        WelcomeActivityEmployer.start(this)
        finish()
        AppLogger.toast(this, getString(R.string.navigate_home))
    }

    override fun navigateToLogin() {
        LoginEmployerActivity.start(this)
        finish()
        AppLogger.toast(this, getString(R.string.navigate_home))
    }

    override fun spinner(languages: Array<String>, spinner: Spinner) {
        baseSpinner(languages, spinner) { onClick ->
            val sector = onClick
            CacheManager.instance.setSector(sector)


        }
    }

    override fun setSectorSpinner() {
        presenter.spinner(
            sectorSpinner, resources.getStringArray(R.array.SectorEmployerData)
        )
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, RegisterEmployerActivity::class.java)
            context.startActivity(intent)
        }

        private val IMAGE_DIRECTORY = "/demonuts"

    }

    override fun toast(message: String) {
        AppLogger.toast(this, message)
    }


}

