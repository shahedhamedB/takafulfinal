package com.moub.PERDAY.ui.employee.employeeWorkInfo

import android.widget.Spinner

interface EmployeeWorkInfoContract {
    fun setEducationalLevelSpinner(onClick:(String)->Unit)
    fun setRecentJobTitleSpinner(onClick:(String)->Unit)
    fun setYearsOfExperienceSpinner(onClick:(String)->Unit)
    fun setskillsSpinner()
    fun spinner(languages:Array<String>,spinner: Spinner,onClick:(String)->Unit)
}