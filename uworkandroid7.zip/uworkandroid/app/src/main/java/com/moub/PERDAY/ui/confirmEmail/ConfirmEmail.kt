package com.moub.PERDAY.ui.confirmEmail

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import com.moub.PERDAY.R
import com.moub.PERDAY.ui.employee.employeePersonalInfo.EmployeeDataActivity
import com.moub.PERDAY.ui.employee.auth.loign.LoginActivity
import com.moub.PERDAY.ui.employee.main.MainActivity
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_confirm_email.*
import kotlinx.android.synthetic.main.activity_question.*

class ConfirmEmail : AppCompatActivity(), ConfirmEmailContract {
    val presenter = ConfirmEmailPresenter(this)
    private var Email :String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirm_email)
        getCode.setOnClickListener {
            presenter.signOut()
            LoginActivity.start(this)
        }
        val bundle = intent.extras
        if (bundle != null) {
            this.Email = bundle.getString("EmployeeEmail")!!


        }
        verfiyBtn.setOnClickListener {
            showProgress()
            presenter.verfiy(this.Email)
            verfiyBtn.isClickable = false

            resendEmailBtn.setOnClickListener {
                showProgress()
                presenter.verfiy(this.Email)
            }
        }
    }

    override fun navigateToData() {
        EmployeeDataActivity.start(this)
        finish()
    }

    override fun setEmailError() {
        email.error = getString(R.string.email_error)

    }

    override fun showProgress() {
        progressBar.visibility = View.VISIBLE

    }

    override fun hideProgress() {
        progressBar.visibility = View.GONE

    }

    override fun toast(message: String) {
        AppLogger.toast(this, message)
    }

    override fun navigatToMain() {
        MainActivity.start(this)
    }


    companion object {
        fun start(context: Context) {
            val intent = Intent(context, ConfirmEmail::class.java)
            context.startActivity(intent)
        }
    }

    private var exit: Boolean? = false
    override fun onBackPressed() {
        if (exit!!) {
            finish() // finish activity
        } else {
            AppLogger.toast(
                this, "Press Back again to Exit."
            )
            exit = true
            Handler().postDelayed(Runnable { exit = false }, 3 * 1000)
        }
    }
}
