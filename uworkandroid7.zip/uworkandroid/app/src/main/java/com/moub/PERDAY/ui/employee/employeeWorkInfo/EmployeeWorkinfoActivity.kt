package com.moub.PERDAY.ui.employee.employeeWorkInfo

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.CheckBox
import android.widget.Spinner
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.ui.base.BaseActivity
import com.moub.PERDAY.ui.employee.welcome.WelcomeActivity
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_employee_workinfo.*


class EmployeeWorkinfoActivity : BaseActivity(), EmployeeWorkInfoContract, EmployeeWorkInfoPresenter.listenerFunctions {
    private var educational: String = ""
    private var experiance: String = ""
    private var recentJobTitle: String = ""
    private var fieldOfExperiance: ArrayList<String> = ArrayList()
    private var saveDay: ArrayList<String> = ArrayList()
    private var numHours: ArrayList<Int> = ArrayList()

    val presenter = EmployeeWorkInfoPresenter(this)
    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_employee_workinfo)
        spinners()
        doneBtn.setOnClickListener { presenter.checklistener(chek1, check2, check3, check4, this) }
        numHours()
        fieldOfExperiance()
        saveDayCheckBox()
        numHoursFun()
        allWeeskCheck.setOnCheckedChangeListener { buttonView, isChecked ->
            checkAll(isChecked)
        }

    }

    private fun checkAll(bool: Boolean){
        mondayCheck.isChecked = bool
        sundayCheck.isChecked = bool
        tuesdayCheck.isChecked = bool
        wednesdayCheckBox.isChecked = bool
        tusdayCheckBox.isChecked = bool
        fridayCheckBox.isChecked = bool
        saturdayCheckBox.isChecked = bool
    }



    fun spinners() {
        setEducationalLevelSpinner { postion -> educational = postion
        CacheManager.instance.setEducationalLevel(postion)}
        setRecentJobTitleSpinner { postion -> recentJobTitle = postion}
        setYearsOfExperienceSpinner { postion -> experiance = postion
        CacheManager.instance.setYearsOfExperience(postion)}
        setskillsSpinner()
    }

    override fun setCheckError() {
        AppLogger.toast(this, "you cannot be field of experience empty !!")
    }

    fun fieldOfExperiance(){
        fieldOfExperiance(this,chek1,check2,check3,check4){data->
            this.fieldOfExperiance = data
        }
    }

    fun saveDayCheckBox (){
        saveDayCheckBox(){data ->
            this.saveDay=data
        }
    }

    fun numHoursFun (){
        presenter.numHoursFun(this,numRecycler){data->
            this.numHours = data
        }
    }
    override fun onSuccess() {
        SaveData()
        WelcomeActivity.start(this)
        finish()


    }


    fun SaveData(){
        fireStoreManager.saveEmployeeWorkInfo(this.educational,this.recentJobTitle,this.experiance,this.fieldOfExperiance,this.saveDay,this.numHours)
    }

    override fun setEducationalLevelSpinner(onClick: (String) -> Unit) {
        presenter.spinner(
            educationalLevel, resources.getStringArray(R.array.Educationallevel)
        ) { postion ->
            onClick(postion)
        }
    }

    override fun setRecentJobTitleSpinner(onClick: (String) -> Unit) {
        presenter.spinner(
            RecentJob, resources.getStringArray(R.array.YearsofExperience)
        ) { postion ->
            onClick(postion)
        }
    }

    override fun setYearsOfExperienceSpinner(onClick: (String) -> Unit) {
        presenter.spinner(
            YearsofExperience, resources.getStringArray(R.array.YearsofExperience)
        ) { postion ->
            onClick(postion)
        }
    }

    override fun setskillsSpinner() {
    }

    override fun spinner(languages: Array<String>, spinner: Spinner, Postion: (String) -> Unit) {
        baseSpinner(languages, spinner){onClick->
            Postion(onClick)
        }
    }
    fun numHours(){
        presenter.numHoursFun(this,numRecycler){}
    }

    fun fieldOfExperiance(
        context: Context,
        chek1: CheckBox,
        chek2: CheckBox,
        chek3: CheckBox,
        chek4: CheckBox,
        data: (ArrayList<String>) -> Unit
    ) {
        val fieldOfExperianceSelect = ArrayList<String>()

        chek1.setOnClickListener{ fieldOfExperianceSelect.add(chek1.text.toString())}
        chek2.setOnClickListener{ fieldOfExperianceSelect.add(chek2.text.toString())}
        chek3.setOnClickListener{ fieldOfExperianceSelect.add(chek3.text.toString())}
        chek4.setOnClickListener { fieldOfExperianceSelect.add(chek4.text.toString())}

        data(fieldOfExperianceSelect)
        AppLogger.toast(context, "$fieldOfExperianceSelect")
    }

    fun saveDayCheckBox(
        data: (ArrayList<String>) -> Unit
    ) {
        val daySelect = ArrayList<String>()

            mondayCheck.setOnClickListener {
                daySelect.add(mondayCheck.text.toString())}
            sundayCheck.setOnClickListener{daySelect.add(sundayCheck.text.toString())}
            tuesdayCheck.setOnClickListener{daySelect.add(tuesdayCheck.text.toString())}
            wednesdayCheckBox.setOnClickListener{daySelect.add(wednesdayCheckBox.text.toString())}
            tusdayCheckBox.setOnClickListener{daySelect.add(tuesdayCheck.text.toString())}
            fridayCheckBox.setOnClickListener{daySelect.add(fridayCheckBox.text.toString())}
            saturdayCheckBox.setOnClickListener{daySelect.add(saturdayCheckBox.text.toString())}
        data(daySelect)

    }
    companion object {
        fun start(context: Context) {
            val intent = Intent(context, EmployeeWorkinfoActivity::class.java)
            context.startActivity(intent)
        }
    }
}
