package com.moub.PERDAY.ui.employer.employerStatus

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.moub.PERDAY.R

class IndividualDataRegistration : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_individual_data_registration)
    }
    companion object {
        fun start(context: Context) {
            val intent = Intent(context, IndividualDataRegistration::class.java)
            context.startActivity(intent)
        }
    }
}
