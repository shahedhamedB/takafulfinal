package com.moub.PERDAY.ui.employee.jobList

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.moub.PERDAY.R
import com.moub.PERDAY.model.PostModel
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_job_list.*

class JobList : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_job_list)
        getComment {
            lisJobReceycler.adapter = JobListAdapter(it, this){ onClick ,size ->
                AppLogger.toast(this,onClick)
                numJobs2.text = size
            }
        }
    }



    fun getComment(onComplete: (MutableList<PostModel>) -> Unit): ListenerRegistration {
        val doc = FirebaseFirestore.getInstance().collection("allPostsJob")
        return doc.addSnapshotListener { querySnapshot, _ ->
            onComplete(querySnapshot!!.toObjects(PostModel::class.java))
        }


    }
    companion object {
        fun start(context: Context) {
            val intent = Intent(context, JobList::class.java)
            context.startActivity(intent)
        }
    }
}
