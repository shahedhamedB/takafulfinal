package com.moub.PERDAY.model

class NotificationsModel(val notificationsStatus :String) {
    constructor(): this ("")
}