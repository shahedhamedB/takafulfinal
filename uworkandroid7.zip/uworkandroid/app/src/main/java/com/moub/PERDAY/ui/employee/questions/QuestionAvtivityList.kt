package com.moub.PERDAY.ui.employee.questions

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.model.QuestionModelEmployee
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_question_avtivity_list.*
import kotlinx.android.synthetic.main.activity_questions_employee.numOfAnswersEmployee

class QuestionAvtivityList : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_question_avtivity_list)
        getDataQuestion {
            val id = FirebaseAuth.getInstance().currentUser!!.uid
            fireStoreManager.getDataQuestionsEmployee{
                answerRecyclerViewEmployee2.adapter = QuestionEmployeeAdapter(it,this){ size,s,d ->
                    numOfAnswersEmployee.text = size
                }
            }
        }

    }

    fun getDataQuestion(onComplete: (MutableList<QuestionModelEmployee>) -> Unit): ListenerRegistration {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = FirebaseFirestore.getInstance()
            .collection("employee").document(id).collection("Question").whereEqualTo("answerStatus", "answer")
        return doc.addSnapshotListener { querySnapshot, firebaseExeption ->
            Log.w("firebaseExeption", "" + firebaseExeption)
            Log.i("firebaseExeption", "" + querySnapshot)
            onComplete(querySnapshot!!.toObjects(QuestionModelEmployee::class.java))

        }
    }


    companion object {
        fun start(context: Context) {
            val intent = Intent(context, QuestionAvtivityList::class.java)
            context.startActivity(intent)
        }
    }

    private var exit: Boolean? = false
    override fun onBackPressed() {
        if (exit!!) {
            finish() // finish activity
        } else {
            AppLogger.toast(
                this, "Press Back again to Exit."
            )
            exit = true
            Handler().postDelayed({ exit = false }, 3 * 1000)
        }
    }
}
