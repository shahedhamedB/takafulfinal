package com.moub.PERDAY.model

class EmployerData(
    val id: String, val email: String, val legalName: String, val representativePerson: String,
    val phone: String,
    val long: String,
    val lat: String,
    val country:String,
    val sectorSpinner: String,
val logo :String,val notiStatus:String
) {
    constructor() : this("", "", "", "", "", "", "", "","","","")
}