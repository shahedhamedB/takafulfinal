package com.moub.PERDAY.ui.employer.auth.register

import android.widget.Spinner

interface RegisterContract {
    fun showProgress()
    fun hideProgress()
    fun setEmailError()
    fun setPhoneError()
    fun setSectorError()
    fun setPersonError()
    fun setPasswordError()
    fun setNameError()
    fun navigateToHome()
    fun navigateToLogin()
    fun toast(message:String)
    fun spinner(languages:Array<String>,spinner: Spinner)
    fun setSectorSpinner()


}