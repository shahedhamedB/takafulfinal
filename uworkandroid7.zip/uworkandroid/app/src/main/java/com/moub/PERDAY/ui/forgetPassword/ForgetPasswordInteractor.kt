package com.moub.PERDAY.ui.forgetPassword

import android.os.Handler
import com.google.firebase.auth.FirebaseAuth

class ForgetPasswordInteractor {
    interface OnResetFinishedListener {
        fun onEmailError()
        fun onSuccess(email: String)
        fun onNavigate()
        fun toast(toast: String)
        fun hideProgress()
    }

    fun restPassword(email: String, listener: OnResetFinishedListener) {
        Handler().postDelayed({
            when {
                email.isEmpty() -> listener.onEmailError()
                else ->
                    listener.onSuccess(email)
            }
        }, 1000)
    }

    fun Rest(email: String, listener: OnResetFinishedListener) {
        val auth = FirebaseAuth.getInstance()
        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    listener.toast("Your password has been successfully sent to your email")
                } else {
                    listener.toast("There is a problem, please check your email")
                }
            }
    }

}