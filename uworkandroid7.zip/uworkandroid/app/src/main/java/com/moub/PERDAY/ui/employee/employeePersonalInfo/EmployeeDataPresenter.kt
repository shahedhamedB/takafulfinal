package com.moub.PERDAY.ui.employee.employeePersonalInfo

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.widget.Spinner
import java.io.IOException
import java.util.*

class EmployeeDataPresenter(val contract: EmployeeDataContract) {

    interface listner {
        fun hideProgressPar()
    }
    fun getCountryName(
        context: Context,
        listner: listner,
        latitude: Double,
        longitude: Double,
        location: (String, String, String,String,String) -> Unit
    ) {
        val geocoder = Geocoder(context, Locale.getDefault())
        val addresses: List<Address>?
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1)
            val result: Address

            if (addresses != null && addresses.isNotEmpty()) {

                location(addresses[0].adminArea, addresses[0].subLocality, addresses[0].countryName,longitude.toString(),latitude.toString())
                listner.hideProgressPar()
            } else null
        } catch (ignored: IOException) {
        }
    }

    fun spinner(spinner: Spinner,language:Array<String> ,onClick:(String)->Unit) {
        contract.spinner(language, spinner){posotion->
            onClick(posotion)
        }
    }
}


