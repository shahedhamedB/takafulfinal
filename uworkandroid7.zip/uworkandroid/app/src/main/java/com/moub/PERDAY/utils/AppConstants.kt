package com.moub.PERDAY.utils

class AppConstants {

    object Status {
        const val PENDING = "pending"
        const val ACCEPTED = "accepted"
    }



}