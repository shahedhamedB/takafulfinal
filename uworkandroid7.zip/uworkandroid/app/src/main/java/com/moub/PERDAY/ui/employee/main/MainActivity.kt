package com.moub.PERDAY.ui.employee.main

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.model.EmployerData
import com.moub.PERDAY.ui.employee.recentlyJob.RecentlyActivity
import com.moub.PERDAY.ui.employee.notifications.NotificationsActivity
import com.moub.PERDAY.ui.userStatus.UserStatus
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_test.*
import kotlinx.android.synthetic.main.nav_header_test.*
import kotlinx.android.synthetic.main.nav_header_test_two.*

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {


    private var NotisStatus: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fragmentAdapter = MainTabsAdapter(this, supportFragmentManager)
        viewPager.adapter = fragmentAdapter

        tabLayout.setupWithViewPager(viewPager)
        viewPager.offscreenPageLimit = 3
        tabLayout.getTabAt(0)!!.setIcon(R.drawable.home)
        tabLayout.getTabAt(1)!!.setIcon(R.drawable.applayed)
        tabLayout.getTabAt(2)!!.setIcon(R.drawable.schedule)
        setSupportActionBar(toolbar)

        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navView.setNavigationItemSelectedListener(this)
        notiMain.setOnClickListener { NotificationsActivity.start(this)
            fireStoreManager.changeNotiStatus()}
            fireStoreManager.getNotificationsListenerforEmployee(notiMain)

        // check notifications


    }
    fun getDataUser(){
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val docRef = FirebaseFirestore.getInstance().collection("employee").document(id)
        docRef.addSnapshotListener(EventListener<DocumentSnapshot> { snapshot, e ->
            if (e != null) {
                Log.w(ContentValues.TAG, "Listen failed.", e)
                return@EventListener
            }
            if (snapshot != null && snapshot.exists()) {
//                val logo : String = snapshot.data!!["logo"].toString()
//                Picasso.get().load(logo).into(MainProfilePic)
                val name :String = snapshot.data!!["userName"].toString()
                employeeNameMain.text = name
                val email :String = snapshot.data!!["email"].toString()
                employeeEmailMain.text = email
                Log.d(ContentValues.TAG, "Current data: ${snapshot.data}")
            } else {
                Log.d(ContentValues.TAG, "Current data: null")
            }
        })
    }



    override fun onBackPressed() {
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.test, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_profile -> {
                // Handle the camera action
            }
            R.id.nav_question -> {

            }
            R.id.recent -> {
                RecentlyActivity.start(this)
            }
            R.id.nav_tools -> {

            }
            R.id.nav_share -> {

            }
            R.id.nav_signOut -> {
                signOut()
            }
        }
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    fun signOut() {
        FirebaseAuth.getInstance().signOut()
        UserStatus.start(this)
        finish()
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, MainActivity::class.java)
            context.startActivity(intent)
        }
    }
}
