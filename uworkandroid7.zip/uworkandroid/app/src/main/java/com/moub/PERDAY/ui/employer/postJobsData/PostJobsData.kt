package com.moub.PERDAY.ui.employer.postJobsData

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Spinner
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.ui.base.BaseActivity
import com.moub.PERDAY.ui.employer.home.Home
import com.moub.PERDAY.ui.employer.main.MainActivityEmployer
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_post_jobs_data.*

class PostJobsData : BaseActivity(), PostJobContract, PostJobsPresenter.listner {

    val presenter = PostJobsPresenter(this)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_post_jobs_data)

        CreatePostJob.setOnClickListener {
            showProgressBar()
            CreatPost()
        }
        
        locationSpinner()
        educationalLevel()
        perWeekSpinner()
        perDaySpinner()
        yearsOfExperiencePost()
        jobCategory()
        paymentSpinner()
        getLegalName()
        getLogo()
    }

    fun getLegalName(){
        fireStoreManager.ChckSplashEmployer(this) { EmployerData ->
            CacheManager.instance.setlegalName(EmployerData.legalName)
        }
    }

    fun getLogo() {
        fireStoreManager.ChckSplashEmployer(this) { EmployerData ->
            CacheManager.instance.setLogo(EmployerData.logo)
        }
    }

    @SuppressLint("ResourceType")
    fun homeFragment() {
        val manager = supportFragmentManager
        val transaction = manager.beginTransaction()
        transaction.replace(android.R.attr.fragment, Home())
        transaction.commit()
    }
    override fun locationSpinner() {
        presenter.spinner(
            locationSpinner, resources.getStringArray(R.array.location)
        ) { onClick ->
            CacheManager.instance.setLocation(onClick)
            if (onClick == "Current Location") {
                showProgressBar()
                getCurrentLocation()
                locationTxt.visibility = View.VISIBLE
            } else {
                locationTxt.visibility = View.GONE
            }
        }
    }

    override fun educationalLevel() {
        presenter.spinner(
            educationalLevel, resources.getStringArray(R.array.educationalLevel)
        ) { onClick ->
            CacheManager.instance.seteducational(onClick)
        }
    }

    override fun perWeekSpinner() {
        presenter.spinner(
            perWeekSpinner, resources.getStringArray(R.array.perWeek)
        ) { onClick ->
            CacheManager.instance.setperWeek(onClick)
            val select = perWeekSelect.text.toString().trim()
            if (onClick == "Specific days") {
                showProgressBar()
                perWeekSelect.visibility = View.VISIBLE
                hideProgressBar()
            } else {
                perWeekSelect.visibility = View.GONE
            }
            if (onClick == "Specific days" || select.isEmpty()) {
                showProgressBar()
                perWeekSelect.error = "Please write Specific days "
                hideProgressBar()
            }
        }
    }

    override fun perDaySpinner() {
        presenter.spinner(
            perDays, resources.getStringArray(R.array.perDay)
        ) { onClick ->
            CacheManager.instance.setperDay(onClick)
            val select = perDaysSelect.text.toString().trim()
            if (onClick == "Specific time") {
                showProgressBar()
                perDaysSelect.visibility = View.VISIBLE
                hideProgressBar()
            } else {
                perDaysSelect.visibility = View.GONE
            }

            if (onClick == "Specific time" || select.isEmpty() || CreatePostJob.isPressed) {
                showProgressBar()
                perDaysSelect.error = "Please write Specific time "
                hideProgressBar()
            }
        }
    }

    override fun yearsOfExperiencePost() {
        presenter.spinner(
            yearsOfExperiencePost, resources.getStringArray(R.array.experienceNeeded)
        ) { onClick ->
            CacheManager.instance.setexperiance(onClick)
        }
    }

    override fun jobCategory() {
        presenter.spinner(
            jobCategory, resources.getStringArray(R.array.jobCategoryPost)
        ) { onClick ->
            CacheManager.instance.setcategory(onClick)
        }
    }

    override fun paymentSpinner() {
        presenter.spinner(
            paymentSpinner, resources.getStringArray(R.array.payment)
        ) { onClick ->
            CacheManager.instance.setpayment(onClick)
        }
    }


    fun CreatPost() {
        val location = CacheManager.instance.getLocation()
        val educational = CacheManager.instance.educational()
        val perWeek = CacheManager.instance.perWeek()
        val perDay = CacheManager.instance.perDay()
        val experiance = CacheManager.instance.experiance()
        val category = CacheManager.instance.category()
        val payment = CacheManager.instance.getPayment()
        presenter.CreatPostJob(
            EmployeePhoto.text.toString().trim(),
            numberOfWorkers.text.toString().trim(),
            location,
            educational,
            perWeek,
            perDay,
            experiance,
            category,
            jobDescription.text.toString().trim(),
            payment,
            this
        )
    }

    override fun hideProgressPar() {
        progressBarPostJob.visibility = View.GONE
    }

    override fun showProgressBar() {
        progressBarPostJob.visibility = View.VISIBLE
    }

    override fun hideProgressBar() {
        progressBarPostJob.visibility = View.GONE
    }

    override fun setJobTitleError() {
        EmployeePhoto.error = "Job title cannot be empty"
        hideProgressPar()
    }

    override fun setNumberOFWrkersError() {
        numberOfWorkers.error = "Number of workers cannot be empty"
        hideProgressPar()
    }

    override fun setlocationSpinnerError() {
        AppLogger.toast(this, "You must enter the work location")
        hideProgressPar()
    }

    override fun seteducationalLevelError() {
        AppLogger.toast(this, "You must choose the educational level")
        hideProgressPar()
    }

    override fun setperWeekSpinnerError() {
        AppLogger.toast(this, "You must choose a working week")
        hideProgressPar()
    }

    override fun setperDaySpinnerError() {
        AppLogger.toast(this, "You must choose a working days")
        hideProgressPar()
    }

    override fun setyearsOfExperiencePostError() {
        AppLogger.toast(this, "You must choose the years of experience")
        hideProgressPar()
    }

    override fun setjobCategoryError() {
        AppLogger.toast(this, "You must choose the job category")
        hideProgressPar()
    }

    override fun setjobDescriptionError() {
        jobDescription.error = "Job description cannot be empty"
        hideProgressPar()
    }

    override fun setpaymentSpinnerError() {
        AppLogger.toast(this, "You must choose the job category")
        hideProgressPar()
    }

    override fun spinner(languages: Array<String>, spinner: Spinner, position: (String) -> Unit) {
        baseSpinner(languages, spinner) { onClick ->
            position(onClick)
        }
    }

    @SuppressLint("SetTextI18n")
    fun getCurrentLocation() {

        getLocation { longValue, latValue ->
            presenter.getCountryName(this, this, latValue, longValue) { location, subLocality, countryName ->
                val country = location
                val SubLocality = subLocality
                val CountryName = countryName
                locationTxt.text = "Current location : $CountryName , $country , $SubLocality"
                CacheManager.instance.setcountry(country)
            }
        }
    }

    override fun onSuccess() {
        AppLogger.toast(this, "your post has been created")
        savePostinFirestore()
        MainActivityEmployer.start(this)
        hideProgressBar()
        startActivityForResult(intent, 0)
        finishActivity(0)
        finish()
        




    }

    override fun showProgressBarContract() {
        showProgressBar()
    }

    override fun hideProgressBarContract() {
        hideProgressBar()
    }

    override fun setJobTitleErrorContract() {
        setJobTitleError()
    }

    override fun setNumberOFWrkersErrorContract() {
        setNumberOFWrkersError()
    }

    override fun setlocationSpinnerErrorContract() {
        setlocationSpinnerError()
    }

    override fun seteducationalLevelErrorContract() {
        seteducationalLevelError()
    }

    override fun setperWeekSpinnerErrorContract() {
        setperWeekSpinnerError()
    }

    override fun setperDaySpinnerErrorContract() {
        setperDaySpinnerError()
    }

    override fun setyearsOfExperiencePostErrorContract() {
        setyearsOfExperiencePostError()
    }

    override fun setjobCategoryErrorContract() {
        setjobCategoryError()
    }

    override fun setjobDescriptionErrorContract() {
        setjobDescriptionError()
    }

    override fun setpaymentSpinnerErrorContract() {
        setpaymentSpinnerError()
    }

    fun savePostinFirestore() {
        val location = CacheManager.instance.getLocation()
        val jobTilte = EmployeePhoto.text.toString().trim()
        val numWorkers = numberOfWorkers.text.toString().trim()
        var week = CacheManager.instance.perWeek()
        if (week == "Specific time") {
            week = perWeekSelect.text.toString().trim()
        } else {
            week = CacheManager.instance.perWeek()
        }
        val educationalLevel = CacheManager.instance.educational()
        var day = CacheManager.instance.perDay()
        if (day == "Specific days") {
            day = perDaysSelect.text.toString().trim()
        }

        val experance = CacheManager.instance.experiance()
        val jobCategory = CacheManager.instance.category()
        val description = jobDescription.text.toString().trim()
        val payment = CacheManager.instance.getPayment()
        val legalName = CacheManager.instance.getlegalName()
        val logo = CacheManager.instance.getLogo()

        fireStoreManager.createPostOnFirestore(
            this,
            legalName,
            jobTilte,
            numWorkers,
            location,
            educationalLevel,
            week,
            day,
            experance,
            jobCategory,
            description,
            payment,logo
        )
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, PostJobsData::class.java)
            context.startActivity(intent)
        }
    }
}
