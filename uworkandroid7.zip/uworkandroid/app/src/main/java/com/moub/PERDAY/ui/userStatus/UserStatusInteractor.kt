package com.moub.PERDAY.ui.userStatus

class UserStatusInteractor {
    interface OnStatusFinishedListener {
        fun onEmployeeNavigate()
        fun onEmployerNavigate()
        fun toast(toast: String)
    }


}