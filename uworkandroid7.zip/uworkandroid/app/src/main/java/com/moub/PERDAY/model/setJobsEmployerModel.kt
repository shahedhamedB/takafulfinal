package com.moub.PERDAY.model

class setJobsEmployerModel(
    val idEmployer: String,
    val id: String,
    val status: String,
    val employeeName: String,
    val experiance: String,
    val location: String,
    val educationalLevel: String,
    val week: ArrayList<String>,
    val day: ArrayList<Int>,
    val jobCategory: ArrayList<String>,
    val time: String,
    val docRequestId: String,val requestId: String,
    val legalName: String,
    val jobTitle: String,val locationEmployer :String,val jobCategoryEmployer:String
) {
    constructor() : this("", "", "", "", "", "", "", ArrayList(), ArrayList(), ArrayList(), "", "","","","","","")
}
