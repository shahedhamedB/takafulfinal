package com.moub.PERDAY.ui.employee.recentlyJob

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.moub.PERDAY.R
import kotlinx.android.synthetic.main.activity_main.tabLayout
import kotlinx.android.synthetic.main.activity_recently2.*

class RecentlyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recently2)
        val fragmentAdapter = tabAdapter(this, supportFragmentManager)
        viewPAgerTwo.adapter = fragmentAdapter
        tabLayout.setupWithViewPager(viewPAgerTwo)
        viewPAgerTwo.offscreenPageLimit = 2


    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, RecentlyActivity::class.java)
            context.startActivity(intent)
        }
    }
}
