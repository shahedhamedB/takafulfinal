package com.moub.PERDAY.ui.employer.main

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.model.EmployerData
import com.moub.PERDAY.ui.employer.applicants.Applicants
import com.moub.PERDAY.ui.employee.notifications.NotificationsActivity
import com.moub.PERDAY.ui.employee.questions.QuestionAvtivityList
import com.moub.PERDAY.ui.userStatus.UserStatus
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main_employer.*
import kotlinx.android.synthetic.main.app_bar_test.*
import kotlinx.android.synthetic.main.nav_header_test_two.*

class MainActivityEmployer : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_employer)
        val fragmentAdapter = MainEmployerTabAdapter(this, supportFragmentManager)
        viewPagerEmployer.adapter = fragmentAdapter

        tabLayout.setupWithViewPager(viewPagerEmployer)
        viewPagerEmployer.offscreenPageLimit = 3
        tabLayout.getTabAt(0)!!.setIcon(R.drawable.home)
        tabLayout.getTabAt(1)!!.setIcon(R.drawable.applayed)
        tabLayout.getTabAt(2)!!.setIcon(R.drawable.postes_final)
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navView.setNavigationItemSelectedListener(this)

        notiMain.setOnClickListener { NotificationsActivity.start(this) }
        fireStoreManager.getNotificationsListenerforEmployer(notiMain)
        getDataUser()
    }
    override fun onBackPressed() {
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
        if (exit!!) {
            finish() // finish activity
        } else {
            Toast.makeText(
                this, "Press Back again to Exit.",
                Toast.LENGTH_SHORT
            ).show()
            exit = true
            Handler().postDelayed(Runnable { exit = false }, 3 * 1000)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.test, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle navigation view item clicks here.
        when (item.itemId) {
            R.id.nav_profile -> {
                // Handle the camera action
            }
            R.id.nav_question -> {
                QuestionAvtivityList.start(this)
            }
            R.id.nav_schedual -> {
                Applicants.start(this)
            }
            R.id.nav_tools -> {

            }
            R.id.nav_Noti -> {

            }
            R.id.nav_share -> {

            }
            R.id.nav_signOut -> {
                signOut()
            }
        }
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    fun getDataUser(){
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val docRef = FirebaseFirestore.getInstance().collection("employerUsers").document(id)
        val data = EmployerData()
        docRef.addSnapshotListener(EventListener<DocumentSnapshot> { snapshot, e ->
            if (e != null) {
                Log.w(ContentValues.TAG, "Listen failed.", e)
                return@EventListener
            }
            if (snapshot != null && snapshot.exists()) {
                val logo : String = snapshot.data!!["logo"].toString()
                Picasso.get().load(logo).into(MainProfilePic)
                val name :String = snapshot.data!!["legalName"].toString()
                EmployerName.text = name
                val email :String = snapshot.data!!["email"].toString()
                textView.text = email
                Log.d(ContentValues.TAG, "Current data: ${snapshot.data}")
            } else {
                Log.d(ContentValues.TAG, "Current data: null")
            }
        })
    }


    fun signOut() {
        FirebaseAuth.getInstance().signOut()
        UserStatus.start(this)
        finish()
    }

    private var exit: Boolean? = false

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, MainActivityEmployer::class.java)
            context.startActivity(intent)
                   }
    }
}
