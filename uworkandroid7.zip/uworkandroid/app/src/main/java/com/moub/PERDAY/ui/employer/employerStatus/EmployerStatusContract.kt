package com.moub.PERDAY.ui.employer.employerStatus

import android.widget.Spinner

interface EmployerStatusContract {
    fun spinner(languages:Array<String>,spinner: Spinner)
    fun setEmployerStatusSpinner()

}