package com.moub.PERDAY.ui.employee.home

import android.widget.Spinner

interface HomeContract {
    fun spinner(languages:Array<String>,spinner: Spinner)
    fun setMilesSpinner()


}