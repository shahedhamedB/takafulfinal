package com.moub.PERDAY.ui.employer.postJobsData

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.os.Handler
import android.widget.Spinner
import java.io.IOException
import java.util.*

class PostJobsPresenter(val contract: PostJobContract) {
    interface listner {
        fun hideProgressPar()
        fun onSuccess()
        fun showProgressBarContract()
        fun hideProgressBarContract()
        fun setJobTitleErrorContract()
        fun setNumberOFWrkersErrorContract()
        fun setlocationSpinnerErrorContract()
        fun seteducationalLevelErrorContract()
        fun setperWeekSpinnerErrorContract()
        fun setperDaySpinnerErrorContract()
        fun setyearsOfExperiencePostErrorContract()
        fun setjobCategoryErrorContract()
        fun setjobDescriptionErrorContract()
        fun setpaymentSpinnerErrorContract()
    }

    fun CreatPostJob(jobTile: String, NumberOfWorkers: String, location: String,educational :String,perWeek:String,perDay:String,experiance:String,category:String,description: String,payment:String, listener: listner) {
        Handler().postDelayed({
            when {
                jobTile.isEmpty() -> listener.setJobTitleErrorContract()
                NumberOfWorkers.isEmpty() -> listener.setNumberOFWrkersErrorContract()
                location == "Chose the location of work" -> listener.setlocationSpinnerErrorContract()
                educational == "Chose the educational level" -> listener.seteducationalLevelErrorContract()
                perWeek == "Chose the Week time" -> listener.setperWeekSpinnerErrorContract()
                perDay == "Chose the day time" -> listener.setperDaySpinnerErrorContract()
                experiance == "Chose the experience needed" -> listener.setyearsOfExperiencePostErrorContract()
                category == "Chose the job category" -> listener.setjobCategoryErrorContract()
                description.isEmpty() -> listener.setjobDescriptionErrorContract()
                payment == "Chose the getPayment schedule" -> listener.setpaymentSpinnerErrorContract()
                else ->

                    listener.onSuccess()

            }
        }, 1000)
    }
    fun getCountryName(
        context: Context,
        listner: listner,
        latitude: Double,
        longitude: Double,
        location: (String, String, String) -> Unit
    ) {
        val geocoder = Geocoder(context, Locale.getDefault())
        val addresses: List<Address>?
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1)
            val result: Address

            if (addresses != null && addresses.isNotEmpty()) {

                location(addresses[0].adminArea, addresses[0].subLocality, addresses[0].countryName)
                listner.hideProgressPar()
            } else null
        } catch (ignored: IOException) {
        }
    }
    fun spinner(spinner: Spinner, language:Array<String> ,onClick :(String)->Unit) {
        contract.spinner(language, spinner){position->
            onClick(position)
        }
    }


}