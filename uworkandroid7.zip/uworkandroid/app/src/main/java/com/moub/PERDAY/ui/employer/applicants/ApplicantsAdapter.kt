package com.moub.PERDAY.ui.employer.applicants

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.moub.PERDAY.ui.employer.applicants.lastApplicants.LastApplicants
import com.moub.PERDAY.ui.employer.applicants.newApplicants.NewApplicants

class ApplicantsAdapter(val context: Context, fm: FragmentManager): FragmentPagerAdapter(fm) {
    var itemsCount = 2
    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> NewApplicants()
            else -> {
                return LastApplicants()
            }
        }
    }

    override fun getCount(): Int {
        return itemsCount
    }

    override fun getPageTitle(position: Int): CharSequence {
        return when (position) {
            0 -> "New applicants"
            else -> {
                return "Last applicants"
            }
        }
    }
}