package com.moub.PERDAY.ui.employee.applayedJob

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.moub.PERDAY.R
import com.moub.PERDAY.model.PostModel

class testAdapter (
    private val items: MutableList<PostModel>, val context: Context, val onClick: ( String, String,String,String,String,String,String,String,String,String) -> Unit
) : RecyclerView.Adapter<testAdapter.viewHolder>() {
    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        val model = items[position]

        onClick(model.location,model.logo,model.numWorkers,model.payment,model.week,model.experance,model.description,model.day,model.educationalLevel,model.jobCategory)


    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): viewHolder {
        return viewHolder(LayoutInflater.from(context).inflate(R.layout.item_job_list, p0, false))
    }

    override fun getItemCount(): Int {
        return items.size

    }


    class viewHolder(view: View) : RecyclerView.ViewHolder(view) {
    }
}