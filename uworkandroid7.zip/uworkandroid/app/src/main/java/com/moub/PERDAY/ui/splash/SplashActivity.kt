package com.moub.PERDAY.ui.splash

import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import com.moub.PERDAY.R
import com.moub.PERDAY.ui.employee.main.MainActivity
import com.moub.PERDAY.ui.employer.main.MainActivityEmployer
import com.moub.PERDAY.ui.userStatus.UserStatus

class SplashActivity : AppCompatActivity(), SplashContract {
    override fun onNavigateStatus() {
        UserStatus.start(this)
        finish()
    }

    override fun onNavigateEmployerHome() {
        MainActivityEmployer.start(this)
        finish()
    }


    private var mDelayHandler: Handler? = null
    private val SPLASH_DELAY: Long = 3000 //3 seconds

    private val mRunnable: Runnable = Runnable {
        if (!isFinishing) {
            presenter.userverification(this)

        }
    }
    private val presenter = SplashPresenter(this, SplashInteractor())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)




        mDelayHandler = Handler()
        mDelayHandler!!.postDelayed(mRunnable, SPLASH_DELAY)
    }

    public override fun onDestroy() {

        if (mDelayHandler != null) {
            mDelayHandler!!.removeCallbacks(mRunnable)
        }
        super.onDestroy()
    }

    override fun navigateToRegister() {
        UserStatus.start(this)
        finish()
    }

    override fun navigateToHome() {
        MainActivity.start(this)
        finish()
    }


}



