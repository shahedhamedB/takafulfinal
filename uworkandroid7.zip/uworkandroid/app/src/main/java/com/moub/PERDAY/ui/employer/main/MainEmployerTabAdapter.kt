package com.moub.PERDAY.ui.employer.main

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.moub.PERDAY.ui.employer.Jobs.Jobs
import com.moub.PERDAY.ui.employer.home.Home
import com.moub.PERDAY.ui.employer.post.PostFragment

class MainEmployerTabAdapter(val context: Context, fm: FragmentManager) : FragmentPagerAdapter(fm) {
    var itemsCount = 3
    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> Home()
            1 -> PostFragment()
            else -> {
                return Jobs()
            }
        }
    }

    override fun getCount(): Int {
        return itemsCount
    }

    override fun getPageTitle(position: Int): CharSequence {
        return when (position) {
            0 -> "Home"
            1 -> "Posts"
            else -> {
                return "Jobs"
            }
        }
    }
}