package com.moub.PERDAY.ui.employer.auth.register

import android.os.Handler
import com.google.firebase.auth.FirebaseAuth
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.utils.AppLogger

class RegisterInteractor {
    interface OnSignUpFinishedListener {
        fun onEmailError()
        fun onPasswordError()
        fun onPhoneError()
        fun onRepresentativePersonError()
        fun onSectorError()
        fun onNameError()
        fun onSuccess(email: String, password: String,legalname: String, representativePerson: String,
                      phone: String,
                      long: String,
                      lat: String,
                      country:String,
                      sectorSpinner: String,logo:String)
        fun onNavigate()
        fun toast(toast: String)
        fun hideProgress()
    }

    fun signUp(email: String, password: String, name: String,phone:String,representativePerson :String,long: String,
               lat: String,country:String,sector:String,logo:String, listener: OnSignUpFinishedListener) {
        Handler().postDelayed({
            when {
                email.isEmpty() -> listener.onEmailError()
                password.isEmpty() -> listener.onPasswordError()
                name.isEmpty() -> listener.onNameError()
                sector == "Sector"  ->listener.onSectorError()
                phone.isEmpty() || phone.length < 9 ->listener.onPhoneError()
                representativePerson.isEmpty() ->listener.onRepresentativePersonError()
                logo.isEmpty()-> errorLogo(listener)


                else ->
                    listener.onSuccess(email, password, name ,representativePerson,phone,long,lat,country,sector,logo)
            }
        }, 1000)
    }

    fun errorLogo(listener: OnSignUpFinishedListener){
        listener.toast("Please upload company logo")
        listener.hideProgress()
    }

    fun SignUpPresenter(
        email: String, passowrd: String, legalName: String, representativePerson: String,
        phone: String,
        long: String,
        lat: String,
        country:String,
        sectorSpinner: String, logo: String,listener: OnSignUpFinishedListener
    ) {
        val auth = FirebaseAuth.getInstance()
        auth.createUserWithEmailAndPassword(email, passowrd)
            .addOnCompleteListener {
                CacheManager.instance.setCheckEmployee("Employer")
                if (!it.isSuccessful) return@addOnCompleteListener
                listener.onNavigate()
                AppLogger.log(
                    "", "Successfully created user with uid: ${it.result!!.user.uid}"
                )
                fireStoreManager.saveEmployerData(
                    email,
                    legalName,
                    representativePerson,
                    phone,
                    long,
                    lat,
                    country,
                    sectorSpinner,logo
                )
                listener.hideProgress()
            }
            .addOnFailureListener {
                AppLogger.log("", "Failed to create user: ${it.message}")
                listener.hideProgress()
                listener.toast(it.toString())
            }
    }



}