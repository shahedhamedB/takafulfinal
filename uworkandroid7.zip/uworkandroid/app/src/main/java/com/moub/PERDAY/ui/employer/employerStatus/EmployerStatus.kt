package com.moub.PERDAY.ui.employer.employerStatus

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Spinner
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.ui.base.BaseActivity
import com.moub.PERDAY.ui.employee.auth.register.RegisterEmployeeActivity
import com.moub.PERDAY.ui.employer.auth.register.RegisterEmployerActivity
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_employer_status.*

class EmployerStatus : BaseActivity(), EmployerStatusContract {
    val presenter = EmployerStatusPresenter(this)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_employer_status)
        setEmployerStatusSpinner()
        clickHereBtn.setOnClickListener {
            RegisterEmployeeActivity.start(this)
            finish()
        }
        nextBtn()
    }

    override fun setEmployerStatusSpinner() {
        presenter.spinner(
            emplyerStatusSpinner, resources.getStringArray(R.array.EmployerStatus)
        )
    }

    override fun spinner(languages: Array<String>, spinner: Spinner) {
        baseSpinner(languages, spinner) { position ->
            val select: Int
            when (position) {
                "Organization" -> {
                    organizationEmail.visibility = View.VISIBLE
                    select = 1
                }
                "Company" -> {
                    AppLogger.toast(this, position)
                    organizationEmail.visibility = View.GONE
                    select = 2
                }
                else -> {
                    AppLogger.toast(this, position)
                    organizationEmail.visibility = View.GONE
                    select = 3
                }
            }
            CacheManager.instance.setSelect(select)
        }
    }

    fun nextBtn() {
        nextEmployerStatusBtn.setOnClickListener {
            val select = CacheManager.instance.getSelect()
            when (select) {
                1 -> {
                    progressBar.visibility = View.VISIBLE
                    if (organizationEmail.text.isEmpty()) {
                        organizationEmail.error = "Email field cannot be empty"
                        progressBar.visibility = View.GONE

                    } else {
                        progressBar.visibility = View.VISIBLE
                        OrganizationDataRegistration.start(this)
                        progressBar.visibility = View.GONE

                    }
                }
                2 -> {
                    progressBar.visibility = View.VISIBLE
                    RegisterEmployerActivity.start(this)
                    progressBar.visibility = View.GONE

                }
                3 -> {
                    progressBar.visibility = View.VISIBLE
                    RegisterEmployerActivity.start(this)
                    progressBar.visibility = View.GONE
                }
            }
        }
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, EmployerStatus::class.java)
            context.startActivity(intent)
        }
    }
}
