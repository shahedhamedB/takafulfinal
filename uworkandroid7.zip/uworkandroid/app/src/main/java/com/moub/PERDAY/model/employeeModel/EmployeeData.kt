package com.moub.PERDAY.model.employeeModel

data class EmployeeData(val id: String, val email: String, val userName: String,val notification:String) {
    constructor() : this(id = "", email = "", userName = "",notification = "")
}