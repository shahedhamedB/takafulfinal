package com.moub.PERDAY.ui.employee.questions

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.model.NotificationsItemsModel
import com.moub.PERDAY.model.QuestionModelEmployee
import kotlinx.android.synthetic.main.activity_questions_employee.*

class QuestionsEmployee : AppCompatActivity() {
    private var RequestId: String = ""
    private var question: String = ""
    private var time: String = ""
    private var requestIdNotification: String = ""
    private var employerId:String = ""
    private var employeeId:String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_questions_employee)
        getBundleData()
        getDataQuestion {
            fireStoreManager.getDataQuestionsEmployee{
                answerRecyclerViewEmployee.adapter = QuestionEmployeeAdapter(it,this){ size,EmployerId,EmployeeId ->
                    numOfAnswersEmployee.text = size
                    this.employerId = EmployerId
                    this.employeeId = EmployeeId
                }
            }
        }
        sendAnswer.setOnClickListener { setAnswer()
        answerEmployee.text.clear()
            deleteNoti()
            setNotiToEmployer()
            createNotificationsItemEmployer(this.employeeId,"question",this.time)
            QuestionAvtivityList.start(this)
            finish()
        }

    }


    fun setNotiToEmployer(){
        FirebaseFirestore.getInstance().collection("employerUsers").document(this.employerId).update("notiStatus","1")
    }


    @SuppressLint("SetTextI18n")
    fun getBundleData() {
        val bundle = intent.extras
        if (bundle != null) {
            this.RequestId = bundle.getString("requestId")!!
            this.requestIdNotification = bundle.getString("requestIdNotification")!!

        }
    }

    fun deleteNoti(){
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        FirebaseFirestore.getInstance().collection("employee").document(id).collection("Notifications").document(this.requestIdNotification).delete()
            .addOnSuccessListener { Log.d("", "DocumentSnapshot successfully deleted!") }
            .addOnFailureListener { e -> Log.w("", "Error deleting document", e) }
    }

    private var EId :String = ""
    private var QuestionModelEmployeeE :String = ""

    fun getDataQuestion(onComplete: (MutableList<QuestionModelEmployee>) -> Unit): ListenerRegistration {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = FirebaseFirestore.getInstance()
            .collection("employee").document(id).collection("Question").whereEqualTo("requestId", this.RequestId)
        return doc.addSnapshotListener { querySnapshot, firebaseExeption ->
            Log.w("firebaseExeption", "" + firebaseExeption)
            Log.i("firebaseExeption", "" + querySnapshot)
            onComplete(querySnapshot!!.toObjects(QuestionModelEmployee::class.java))
            val employerId = querySnapshot.toObjects(QuestionModelEmployee::class.java)[0].employerId
            this.EId = employerId
            this.question = querySnapshot.toObjects(QuestionModelEmployee::class.java)[0].question
            this.time = querySnapshot.toObjects(QuestionModelEmployee::class.java)[0].time
            this.QuestionModelEmployeeE = querySnapshot.toObjects(QuestionModelEmployee::class.java)[0].requestIdEmployer
            questionTxtEmployee.text = this.question
            timeAnswerEmployer.text = this.time
        }
    }
    fun setAnswer(){
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = fireStoreManager.db.collection("employee").document(id).collection("Question").document(this.RequestId)
        val docEmployer = fireStoreManager.db.collection("employerUsers").document(this.EId).collection("Question").document(this.QuestionModelEmployeeE)
        doc.update("answerStatus" , "answer")
        doc.update("answer" , answerEmployee.text.toString())

        docEmployer.update ("answerStatus" , "answer")
        docEmployer.update("answer" , answerEmployee.text.toString())
    }


    fun createNotificationsItemEmployer(EmployeeId: String, notificationsType: String, time: String) {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = fireStoreManager.db.collection("employerUsers").document(id).collection("Notifications").document()
        val requestId = doc.id
        val notiItems =
            NotificationsItemsModel(id, EmployeeId, notificationsType, this.QuestionModelEmployeeE, time, requestId)
        doc.set(notiItems)
    }



    companion object {
        fun start(context: Context) {
            val intent = Intent(context, QuestionsEmployee::class.java)
            context.startActivity(intent)
        }
    }
}
