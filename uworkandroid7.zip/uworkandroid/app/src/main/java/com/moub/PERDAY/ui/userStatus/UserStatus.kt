package com.moub.PERDAY.ui.userStatus

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.moub.PERDAY.R
import com.moub.PERDAY.ui.employee.auth.register.RegisterEmployeeActivity
import com.moub.PERDAY.ui.employer.employerStatus.EmployerStatus
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_user_status.*


class UserStatus : AppCompatActivity(), UserStatusView {
    override fun showProgress() {
        progressBar.visibility = View.VISIBLE
    }

    override fun hideProgress() {
        progressBar.visibility = View.GONE
    }

    override fun toast(message: String) {
        AppLogger.toast(this, message)
    }


    private val presenter = UserStatusPresenter(this, UserStatusInteractor())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_status)
        employeeBtn.setOnClickListener { employee() }
        emplyerBtn.setOnClickListener { employerNavigate() }
    }

    fun employee() {
        presenter.employee()
    }

    override fun employerNavigate() {
        EmployerStatus.start(this)
    }

    override fun employeeNavigate() {
        RegisterEmployeeActivity.start(this)
    }


    companion object {
        fun start(context: Context) {
            val intent = Intent(context, UserStatus::class.java)
            context.startActivity(intent)
        }
    }

    private var exit: Boolean? = false
    override fun onBackPressed() {
        if (exit!!) {
            finish() // finish activity
        } else {
            Toast.makeText(
                this, "Press Back again to Exit.",
                Toast.LENGTH_SHORT
            ).show()
            exit = true
            Handler().postDelayed(Runnable { exit = false }, 3 * 1000)
        }
    }


}
