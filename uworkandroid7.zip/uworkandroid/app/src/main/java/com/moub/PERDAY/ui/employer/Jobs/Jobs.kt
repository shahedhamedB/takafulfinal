package com.moub.PERDAY.ui.employer.Jobs


import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.managers.fireStoreManager
import com.moub.PERDAY.model.saveApplaiedEmployeeModel
import com.moub.PERDAY.model.setJobsEmployerModel
import com.moub.PERDAY.ui.employer.rateEmployee.Rate
import com.moub.PERDAY.utils.AppConstants
import kotlinx.android.synthetic.main.activity_question.*
import kotlinx.android.synthetic.main.fragment_jobs.*
import kotlinx.android.synthetic.main.fragment_last_applicants2.*


class Jobs : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View? {
        val view= inflater.inflate(R.layout.fragment_jobs, container, false)
        getComment {
            jobRecyclerView.adapter =JobsAdapter(it,          activity!!
                ) { confirmEmployeeBtn2, requestId ->
                    confirmEmployeeBtn2.setOnClickListener {
                        val intent = Intent(activity!!, Rate::class.java)
                        activity!!.startActivity(intent)
                        fireStoreManager.deleteJobs(requestId)
                    }
                }
        }
        return view
    }
    fun getComment(onComplete: (MutableList<setJobsEmployerModel>) -> Unit): ListenerRegistration {
        val id = FirebaseAuth.getInstance().currentUser!!.uid
        val doc = FirebaseFirestore.getInstance()
            .collection("employerUsers")
            .document(id) // idEmployer
            .collection("Jobs").whereEqualTo("status", "unComplete")
        return doc.addSnapshotListener { querySnapshot, firebaseExeption ->
            Log.w("firebaseExeption", "" + firebaseExeption)
            Log.i("firebaseExeption", "" + querySnapshot)
            onComplete(querySnapshot!!.toObjects(setJobsEmployerModel::class.java))

        }
    }


}
