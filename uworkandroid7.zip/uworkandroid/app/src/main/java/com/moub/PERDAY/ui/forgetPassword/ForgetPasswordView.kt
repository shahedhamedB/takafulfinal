package com.moub.PERDAY.ui.forgetPassword

interface ForgetPasswordView {
    fun showProgress()
    fun hideProgress()
    fun setEmailError()
    fun navigateToHome()
    fun toast(message:String)
}