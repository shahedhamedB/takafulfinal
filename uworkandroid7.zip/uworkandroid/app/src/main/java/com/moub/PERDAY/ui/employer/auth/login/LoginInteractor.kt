package com.moub.PERDAY.ui.employer.auth.login

import android.content.Context
import android.os.Handler
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.managers.fireStoreManager

class LoginInteractor {
    interface OnLoginFinishedListener {
        fun onEmailError()
        fun onPasswordError()
        fun onSuccess(email: String, password: String,context: Context)
        fun onNavigate()
        fun toast(toast: String)
        fun hideProgress()
    }

    fun logIn(email: String, password: String, listener: OnLoginFinishedListener,context: Context) {
        Handler().postDelayed({
            when {
                email.isEmpty() -> listener.onEmailError()
                password.isEmpty() -> listener.onPasswordError()
                else ->
                    listener.onSuccess(email, password,context)
            }
        }, 1000)
    }

    fun employerLogin(email: String, passowrd: String,context: Context, listener: OnLoginFinishedListener) {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, passowrd)
            .addOnCompleteListener {
                CacheManager.instance.setCheckEmployee("Employer")
                if (!it.isSuccessful) return@addOnCompleteListener
                Log.d("Login", "Successfully logged in: ${it.result!!.user.uid}")
                fireStoreManager.checkUserEmployer { EmployerData ->
                    val userEmail = EmployerData.email
                    if (email == userEmail) {
                        listener.onNavigate()
                    }else{
                        listener.toast("This e-mail address is not registered as an employer")
                    }
                }
            }
            .addOnFailureListener {
                listener.toast(it.toString())
                listener.hideProgress()
            }
    }

}