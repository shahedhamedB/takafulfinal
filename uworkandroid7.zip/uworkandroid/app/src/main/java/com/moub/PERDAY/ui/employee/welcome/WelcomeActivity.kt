package com.moub.PERDAY.ui.employee.welcome

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.TextView
import com.moub.PERDAY.R
import com.moub.PERDAY.managers.CacheManager
import com.moub.PERDAY.ui.employee.main.MainActivity
import kotlinx.android.synthetic.main.activity_welcome.*

class WelcomeActivity : AppCompatActivity(), WelcomeContract {
    private var mDelayHandler: Handler? = null
    private val SPLASH_DELAY: Long = 3000 //3 seconds

    private val mRunnable: Runnable = Runnable {
        if (!isFinishing) {
            presenter.userverification()

        }
    }
    val presenter = WelcomePresenter(this, WelcomeInteractor())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

        mDelayHandler = Handler()
        mDelayHandler!!.postDelayed(mRunnable, SPLASH_DELAY)
        val name = CacheManager.instance.getUserName()
        textUserName.text = name
        animationTxt(textUserName)
        animationTxt(txtView1)
        animationTxt(txtView2)


    }

    public override fun onDestroy() {

        if (mDelayHandler != null) {
            mDelayHandler!!.removeCallbacks(mRunnable)
        }
        super.onDestroy()
    }

    override fun navigateToRegister() {
        MainActivity.start(this)
        finish()
        CacheManager.instance.setCheckEmployee("Employee")

    }

    override fun navigateToHome() {


    }

    override fun animationTxt(text: TextView) {
        presenter.animation(text)
    }


    companion object {
        fun start(context: Context) {
            val intent = Intent(context, WelcomeActivity::class.java)
            context.startActivity(intent)
        }
    }
}
