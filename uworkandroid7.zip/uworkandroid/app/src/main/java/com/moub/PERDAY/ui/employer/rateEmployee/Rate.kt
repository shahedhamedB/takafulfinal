package com.moub.PERDAY.ui.employer.rateEmployee

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import com.moub.PERDAY.R
import com.moub.PERDAY.ui.employer.main.MainActivityEmployer
import com.moub.PERDAY.utils.AppLogger
import kotlinx.android.synthetic.main.activity_rate.*

class Rate : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rate)

        sendBtn.setOnClickListener { MainActivityEmployer.start(this)
        finish()}
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, Rate::class.java)
            context.startActivity(intent)
        }
    }

    private var exit: Boolean? = false
    override fun onBackPressed() {
        if (exit!!) {
            finish() // finish activity
        } else {
            AppLogger.toast(
                this, "Press Back again to Exit."
            )
            exit = true
            Handler().postDelayed({ exit = false }, 3 * 1000)
        }
    }
}
