package com.moub.PERDAY.ui.employee.jobList

class JobListPresenter {


    fun applay(){

    }
}