package com.moub.PERDAY.model

class EmployeeWorkInfo(
    val id: String, val educational: String, val recentJobTitle: String, val yearOfExperiance: String,
    val fieldOfExperiance: ArrayList<String>,
    val weekDaysAvalability: ArrayList<String>,
    val dayHours: ArrayList<Int>
) {
    constructor() : this("", "", "", "",  ArrayList(), ArrayList() ,  ArrayList())
}